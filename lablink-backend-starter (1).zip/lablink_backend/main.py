from datetime import date, time, datetime
from pathlib import Path
import sqlite3
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

DB_PATH = Path(__file__).parent / "lablink.db"
def connect():
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c
def init_db():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT, equipment_id TEXT NOT NULL, equipment_name TEXT NOT NULL,
        student_name TEXT NOT NULL, project_name TEXT NOT NULL, project_description TEXT NOT NULL DEFAULT '',
        date TEXT NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL, deadline TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        review_note TEXT NOT NULL DEFAULT '')""")
        db.execute("CREATE INDEX IF NOT EXISTS idx_slot ON bookings(equipment_id,date,status)")
app=FastAPI(title="LabLink API",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_methods=["*"],allow_headers=["*"])
@app.on_event("startup")
def startup(): init_db()
class BookingCreate(BaseModel):
    equipment_id:str; equipment_name:str; student_name:str=Field(min_length=1,max_length=100)
    project_name:str=Field(min_length=1,max_length=150); project_description:str=""
    date:date; start_time:time; end_time:time; deadline:date
class StatusUpdate(BaseModel): status:str; review_note:str=""
def conflict(db, data, exclude_id=None):
    rows=db.execute("SELECT * FROM bookings WHERE equipment_id=? AND date=? AND status IN ('pending','approved')",(data['equipment_id'],data['date'])).fetchall()
    for r in rows:
        if exclude_id is not None and r['id']==exclude_id: continue
        if not (data['end_time']<=r['start_time'] or data['start_time']>=r['end_time']): return r
    return None
@app.get('/')
def root(): return {"app":"LabLink API","version":"1.0.0"}
@app.get('/api/health')
def health(): return {"status":"ok","database":"sqlite"}
@app.get('/api/bookings')
def list_bookings():
    with connect() as db: return [dict(r) for r in db.execute('SELECT * FROM bookings ORDER BY date,start_time').fetchall()]
@app.post('/api/bookings')
def create_booking(p:BookingCreate):
    if p.start_time>=p.end_time: raise HTTPException(400,'End time must be after start time.')
    if p.start_time<time(8,0) or p.end_time>time(20,0): raise HTTPException(400,'Bookings must be between 08:00 and 20:00.')
    if p.date<date.today(): raise HTTPException(400,'Cannot book a date in the past.')
    if p.deadline<p.date: raise HTTPException(400,'Booking date must not be after the project deadline.')
    if p.date==date.today() and p.start_time<=datetime.now().time().replace(second=0,microsecond=0): raise HTTPException(400,'Cannot book a time that has already passed.')
    d={k:(v.isoformat() if hasattr(v,'isoformat') else v) for k,v in p.model_dump().items()}
    with connect() as db:
        cl=conflict(db,d)
        if cl: raise HTTPException(409,{'message':'Time slot conflict','conflicting_booking':dict(cl)})
        cur=db.execute("INSERT INTO bookings(equipment_id,equipment_name,student_name,project_name,project_description,date,start_time,end_time,deadline,status) VALUES(?,?,?,?,?,?,?,?,?,'pending')",(d['equipment_id'],d['equipment_name'],d['student_name'],d['project_name'],d['project_description'],d['date'],d['start_time'],d['end_time'],d['deadline']))
        return dict(db.execute('SELECT * FROM bookings WHERE id=?',(cur.lastrowid,)).fetchone())
@app.patch('/api/bookings/{booking_id}/status')
def update_status(booking_id:int,p:StatusUpdate):
    if p.status not in {'approved','rejected','cancelled','pending'}: raise HTTPException(400,'Invalid status.')
    with connect() as db:
        r=db.execute('SELECT * FROM bookings WHERE id=?',(booking_id,)).fetchone()
        if not r: raise HTTPException(404,'Booking not found.')
        if p.status=='approved':
            cl=conflict(db,dict(r),exclude_id=booking_id)
            if cl: raise HTTPException(409,{'message':'Approval blocked due to scheduling conflict','conflicting_booking':dict(cl)})
        db.execute('UPDATE bookings SET status=?,review_note=? WHERE id=?',(p.status,p.review_note,booking_id))
        return dict(db.execute('SELECT * FROM bookings WHERE id=?',(booking_id,)).fetchone())
@app.delete('/api/bookings/{booking_id}')
def cancel_booking(booking_id:int):
    with connect() as db:
        r=db.execute('SELECT * FROM bookings WHERE id=?',(booking_id,)).fetchone()
        if not r: raise HTTPException(404,'Booking not found.')
        if r['status'] not in ('pending','approved'): raise HTTPException(400,'This booking cannot be cancelled.')
        db.execute("UPDATE bookings SET status='cancelled' WHERE id=?",(booking_id,))
        return {'message':'Booking cancelled','id':booking_id}
@app.delete('/api/bookings')
def clear_bookings():
    with connect() as db: db.execute('DELETE FROM bookings')
    return {'message':'Demo bookings cleared'}
