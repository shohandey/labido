from fastapi import APIRouter, HTTPException, Request, BackgroundTasks
import asyncio
from pydantic import BaseModel
from backend.database import get_database
from backend.recovery.engine import RecoveryEngine
import os
import subprocess

router = APIRouter(prefix="/api/recovery", tags=["recovery"])

class RecoveryRequest(BaseModel):
    evidence_id: str

async def run_recovery_task(app_state, evidence_id: str, job_id: str):
    db = await get_database()
    evidence = await db["evidence"].find_one({"_id": evidence_id})
    if not evidence:
        return
        
    filepath = evidence.get("filepath", "")
    vendor = evidence.get("vendor", "generic")
    output_dir = os.path.join(app_state.config.get("WORKING_DIR", "/tmp/working"), evidence_id)
    
    engine = RecoveryEngine()
    results = await engine.run_recovery(evidence_id, filepath, vendor, output_dir, app_state.job_service, job_id)
    
    await db["recovery_results"].insert_one({"evidence_id": evidence_id, "results": results})
    if app_state.audit_service:
        await app_state.audit_service.log_event("recovery_completed", evidence_id)

@router.post("")
async def start_recovery(req: RecoveryRequest, request: Request, background_tasks: BackgroundTasks):
    db = await get_database()
    evidence = await db["evidence"].find_one({"_id": req.evidence_id})
    if not evidence:
        raise HTTPException(status_code=404, detail="Evidence not found")
        
    job_service = request.app.state.job_service
    job_id = await job_service.create_job("recovery", {"evidence_id": req.evidence_id})
    
    background_tasks.add_task(run_recovery_task, request.app.state, req.evidence_id, job_id)
    return {"job_id": job_id, "message": "Recovery started"}

@router.get("/{evidence_id}")
async def get_recovery_results(evidence_id: str):
    db = await get_database()
    result = await db["recovery_results"].find_one({"evidence_id": evidence_id})
    if not result:
        raise HTTPException(status_code=404, detail="Recovery results not found")
    result['_id'] = str(result['_id'])
    return result
