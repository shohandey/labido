import os
from .base import VendorAdapter

class DahuaAdapter(VendorAdapter):
    vendor_name = 'dahua'
    
    async def identify(self, filepath: str) -> bool:
        filename = os.path.basename(filepath).lower()
        if 'dahua' in filename:
            return True
        return False
        
    async def parse_metadata(self, filepath: str) -> dict:
        return {"vendor": self.vendor_name, "is_demo": True, "details": "Dahua basic metadata"}
        
    def capabilities(self) -> set:
        return {'import', 'repair_stream'}
