from fastapi import APIRouter, Request, Query
from backend.database import get_database
from typing import Optional

router = APIRouter(tags=["events"])

@router.get("/api/events")
async def get_events(
    case_id: Optional[str] = None,
    evidence_id: Optional[str] = None,
    event_type: Optional[str] = None,
    is_demo: Optional[bool] = None,
    skip: int = 0,
    limit: int = 100
):
    db = await get_database()
    query = {}
    if case_id: query["case_id"] = case_id
    if evidence_id: query["evidence_id"] = evidence_id
    if event_type: query["event_type"] = event_type
    if is_demo is not None: query["is_demo"] = is_demo
    
    cursor = db["analysis_events"].find(query).skip(skip).limit(limit)
    events = await cursor.to_list(length=limit)
    for ev in events:
        ev["_id"] = str(ev["_id"])
    return events

@router.get("/api/timeline")
async def get_timeline(case_id: str, request: Request):
    db = await get_database()
    timeline_service = request.app.state.timeline_service
    return await timeline_service.get_timeline(db, case_id)
