import os
import shutil
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from config import get_settings
from database import init_db
from services.ledger_service import LedgerService
from services.audit_service import AuditService
from services.job_service import JobService
from services.metadata_service import MetadataService

from routers import health, cases, evidence, acquisition, audit, ledger, search

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    if not shutil.which("ffmpeg"):
        logger.warning("ffmpeg not found in PATH!")
    if not shutil.which("ffprobe"):
        logger.warning("ffprobe not found in PATH!")
        
    await init_db(app)
    
    settings = get_settings()
    for d in [
        os.path.join(settings.EVIDENCE_ROOT, "originals"),
        os.path.join(settings.EVIDENCE_ROOT, "working"),
        os.path.join(settings.EVIDENCE_ROOT, "thumbnails"),
        os.path.join(settings.EVIDENCE_ROOT, "carved"),
        settings.REPORT_ROOT
    ]:
        os.makedirs(d, exist_ok=True)
        
    app.state.ledger_service = LedgerService(app.state.db)
    app.state.audit_service = AuditService(app.state.db, app.state.ledger_service)
    app.state.job_service = JobService(app.state.db)
    app.state.metadata_service = MetadataService()
    
    yield

app = FastAPI(title="PramaanSync", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/api")
app.include_router(cases.router, prefix="/api")
app.include_router(evidence.router, prefix="/api")
app.include_router(acquisition.router, prefix="/api")
app.include_router(audit.router, prefix="/api")
app.include_router(ledger.router, prefix="/api")
app.include_router(search.router, prefix="/api")

app.mount("/evidence/thumbnails", StaticFiles(directory="./evidence/thumbnails"), name="thumbnails")

@app.get("/")
def read_root():
    return {"app": "PramaanSync", "version": "1.0.0"}
