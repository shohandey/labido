import os

class IndexParser:
    async def parse(self, filepath: str, vendor: str) -> dict:
        if vendor == 'hikvision':
            return {
                "success": True,
                "details": {
                    "method": "index_scan",
                    "records_found": 120,
                    "is_demo": True
                }
            }
        return {"success": False, "details": {"reason": "unsupported for this vendor"}}
