from abc import ABC, abstractmethod

class VendorAdapter(ABC):
    vendor_name: str = 'generic'
    
    @abstractmethod
    async def identify(self, filepath: str) -> bool:
        """Check if file matches this vendor's format"""
        pass
    
    @abstractmethod
    async def parse_metadata(self, filepath: str) -> dict:
        """Extract vendor-specific metadata"""
        pass
    
    @abstractmethod
    def capabilities(self) -> set:
        """Return set of supported capabilities"""
        pass
