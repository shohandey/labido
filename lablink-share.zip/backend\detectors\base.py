from abc import ABC, abstractmethod
import numpy as np

class Detector(ABC):
    @abstractmethod
    def detect(self, frame: np.ndarray) -> list[dict]:
        """Detect objects in frame. Return list of {label, confidence, bbox, is_demo}"""
        pass
    
    @abstractmethod
    def get_mode(self) -> str:
        pass
