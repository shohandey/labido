import subprocess
import logging

logger = logging.getLogger(__name__)

class StreamRepair:
    async def repair(self, input_path: str, output_path: str) -> dict:
        try:
            cmd = [
                'ffmpeg', '-err_detect', 'ignore_err', '-fflags', '+genpts+igndts',
                '-i', input_path, '-c', 'copy', '-y', output_path
            ]
            process = subprocess.run(cmd, capture_output=True, text=True)
            success = process.returncode == 0
            
            recovered_fraction = 1.0
            if success:
                try:
                    def get_duration(p):
                        probe_cmd = ['ffprobe', '-v', 'quiet', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', p]
                        res = subprocess.run(probe_cmd, capture_output=True, text=True)
                        return float(res.stdout.strip())
                    
                    orig_dur = get_duration(input_path)
                    new_dur = get_duration(output_path)
                    if orig_dur > 0:
                        recovered_fraction = min(1.0, new_dur / orig_dur)
                except Exception:
                    pass
                    
            return {
                "success": success,
                "output_path": output_path if success else None,
                "details": {
                    "method": "ffmpeg_remux",
                    "error_handling": "ignore_err+genpts+igndts",
                    "stderr": process.stderr[-500:] if not success else None
                },
                "recovered_fraction": recovered_fraction
            }
        except Exception as e:
            logger.error(f"Stream repair failed: {e}")
            return {"success": False, "details": {"error": str(e)}}
