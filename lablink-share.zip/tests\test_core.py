"""
PramaanSync Test Suite

Tests for:
- SHA-256 hashing
- Hash mismatch detection
- Ledger validity
- Ledger tampering detection
- Evidence acquisition flow
- Audit creation
- Timeline clustering
"""
import asyncio
import hashlib
import os
import sys
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest
import pytest_asyncio

# Add backend to path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))


# ══════════════════════════════════════════════════
# FIXTURES
# ══════════════════════════════════════════════════

@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    with tempfile.TemporaryDirectory() as d:
        yield d


@pytest.fixture
def sample_file(temp_dir):
    """Create a sample file with known content."""
    path = os.path.join(temp_dir, "test_sample.mp4")
    with open(path, "wb") as f:
        f.write(b"PramaanSync test content for SHA-256 verification")
    return path


@pytest.fixture
def modified_file(temp_dir):
    """Create a modified version of the sample file."""
    path = os.path.join(temp_dir, "test_modified.mp4")
    with open(path, "wb") as f:
        f.write(b"PramaanSync test content for SHA-256 verification - MODIFIED")
    return path


@pytest.fixture
def identical_file(temp_dir, sample_file):
    """Create an identical copy of the sample file."""
    import shutil
    path = os.path.join(temp_dir, "test_identical.mp4")
    shutil.copy2(sample_file, path)
    return path


class MockDB:
    """Mock MongoDB database for testing."""

    def __init__(self):
        self.collections = {}

    def __getitem__(self, name):
        if name not in self.collections:
            self.collections[name] = MockCollection(name)
        return self.collections[name]

    def __getattr__(self, name):
        return self[name]


class MockCollection:
    """Mock MongoDB collection for testing."""

    def __init__(self, name):
        self.name = name
        self.documents = []
        self._id_counter = 0

    async def insert_one(self, doc):
        self._id_counter += 1
        if "_id" not in doc:
            doc["_id"] = str(uuid.uuid4())
        self.documents.append(doc.copy())
        result = MagicMock()
        result.inserted_id = doc["_id"]
        return result

    async def find_one(self, filter_dict=None, **kwargs):
        if not filter_dict:
            return self.documents[0] if self.documents else None
        for doc in self.documents:
            if all(doc.get(k) == v for k, v in filter_dict.items()):
                return doc
        return None

    def find(self, filter_dict=None, **kwargs):
        return MockCursor(self.documents, filter_dict)

    async def count_documents(self, filter_dict=None):
        if not filter_dict:
            return len(self.documents)
        return sum(1 for d in self.documents
                   if all(d.get(k) == v for k, v in filter_dict.items()))

    async def update_one(self, filter_dict, update):
        for doc in self.documents:
            if all(doc.get(k) == v for k, v in filter_dict.items()):
                if "$set" in update:
                    doc.update(update["$set"])
                return MagicMock(modified_count=1)
        return MagicMock(modified_count=0)

    async def create_index(self, *args, **kwargs):
        pass

    async def drop(self):
        self.documents.clear()


class MockCursor:
    """Mock MongoDB cursor."""

    def __init__(self, documents, filter_dict=None):
        if filter_dict:
            self._docs = [d for d in documents
                         if all(d.get(k) == v for k, v in filter_dict.items())]
        else:
            self._docs = list(documents)
        self._sort_key = None

    def sort(self, key, direction=1):
        if isinstance(key, str):
            self._docs.sort(key=lambda d: d.get(key, 0),
                          reverse=(direction == -1))
        elif isinstance(key, list):
            k, d = key[0] if isinstance(key[0], tuple) else (key[0], 1)
            self._docs.sort(key=lambda doc: doc.get(k, 0),
                          reverse=(d == -1))
        return self

    def skip(self, n):
        self._docs = self._docs[n:]
        return self

    def limit(self, n):
        self._docs = self._docs[:n]
        return self

    async def to_list(self, length=None):
        if length:
            return self._docs[:length]
        return self._docs

    def __aiter__(self):
        self._iter = iter(self._docs)
        return self

    async def __anext__(self):
        try:
            return next(self._iter)
        except StopIteration:
            raise StopAsyncIteration


# ══════════════════════════════════════════════════
# SHA-256 HASHING TESTS
# ══════════════════════════════════════════════════

class TestHashing:
    """Tests for SHA-256 hashing service."""

    @pytest.mark.asyncio
    async def test_same_file_same_hash(self, sample_file, identical_file):
        """Same file content must produce same SHA-256 hash."""
        from services.hashing import calculate_sha256

        hash1 = await calculate_sha256(sample_file)
        hash2 = await calculate_sha256(identical_file)

        assert hash1 == hash2
        assert len(hash1) == 64  # SHA-256 hex digest length

    @pytest.mark.asyncio
    async def test_different_file_different_hash(self, sample_file, modified_file):
        """Modified file must produce different SHA-256 hash."""
        from services.hashing import calculate_sha256

        hash1 = await calculate_sha256(sample_file)
        hash2 = await calculate_sha256(modified_file)

        assert hash1 != hash2

    @pytest.mark.asyncio
    async def test_hash_matches_hashlib(self, sample_file):
        """Our hash must match standard hashlib calculation."""
        from services.hashing import calculate_sha256

        our_hash = await calculate_sha256(sample_file)

        # Calculate with hashlib directly
        h = hashlib.sha256()
        with open(sample_file, "rb") as f:
            h.update(f.read())
        expected = h.hexdigest()

        assert our_hash == expected

    @pytest.mark.asyncio
    async def test_verify_hash_match(self, sample_file):
        """Verify hash should return match=True for correct hash."""
        from services.hashing import calculate_sha256, verify_hash

        correct_hash = await calculate_sha256(sample_file)
        result = await verify_hash(sample_file, correct_hash)

        assert result["match"] is True
        assert result["expected"] == correct_hash
        assert result["actual"] == correct_hash

    @pytest.mark.asyncio
    async def test_verify_hash_mismatch(self, sample_file):
        """Verify hash should return match=False for wrong hash."""
        from services.hashing import verify_hash

        wrong_hash = "a" * 64
        result = await verify_hash(sample_file, wrong_hash)

        assert result["match"] is False
        assert result["expected"] == wrong_hash
        assert result["actual"] != wrong_hash

    @pytest.mark.asyncio
    async def test_hash_is_deterministic(self, sample_file):
        """Multiple hash calculations of same file must be identical."""
        from services.hashing import calculate_sha256

        hashes = [await calculate_sha256(sample_file) for _ in range(5)]
        assert len(set(hashes)) == 1


# ══════════════════════════════════════════════════
# LEDGER TESTS
# ══════════════════════════════════════════════════

class TestLedger:
    """Tests for tamper-evident ledger service."""

    @pytest.mark.asyncio
    async def test_genesis_block(self):
        """First block should have previous_hash of all zeros."""
        from services.ledger_service import LedgerService

        db = MockDB()
        ls = LedgerService(db)

        block = await ls.append_block("GENESIS", "", "")
        assert block["block_no"] == 1
        assert block["previous_hash"] == "0" * 64
        assert len(block["current_hash"]) == 64

    @pytest.mark.asyncio
    async def test_chain_links(self):
        """Each block's previous_hash must match prior block's current_hash."""
        from services.ledger_service import LedgerService

        db = MockDB()
        ls = LedgerService(db)

        block1 = await ls.append_block("ACTION_1", "ev1", "hash1")
        block2 = await ls.append_block("ACTION_2", "ev2", "hash2")
        block3 = await ls.append_block("ACTION_3", "ev3", "hash3")

        assert block2["previous_hash"] == block1["current_hash"]
        assert block3["previous_hash"] == block2["current_hash"]

    @pytest.mark.asyncio
    async def test_valid_chain_verification(self):
        """Valid chain should pass verification."""
        from services.ledger_service import LedgerService

        db = MockDB()
        ls = LedgerService(db)

        await ls.append_block("GENESIS", "", "")
        await ls.append_block("ACQUIRE", "ev1", "hash1")
        await ls.append_block("VERIFY", "ev1", "hash1")

        result = await ls.verify_chain()
        assert result["valid"] is True
        assert result["first_bad_block"] is None

    @pytest.mark.asyncio
    async def test_tampered_chain_detection(self):
        """Tampered chain must be detected as invalid."""
        from services.ledger_service import LedgerService

        db = MockDB()
        ls = LedgerService(db)

        await ls.append_block("GENESIS", "", "")
        await ls.append_block("ACQUIRE", "ev1", "hash1")
        await ls.append_block("VERIFY", "ev1", "hash1")

        # Tamper with block 2
        blocks = db.collections["ledger_blocks"].documents
        blocks[1]["current_hash"] = "tampered_" + "0" * 55

        result = await ls.verify_chain()
        assert result["valid"] is False
        assert result["first_bad_block"] is not None

    @pytest.mark.asyncio
    async def test_sequential_block_numbers(self):
        """Block numbers must be sequential starting from 1."""
        from services.ledger_service import LedgerService

        db = MockDB()
        ls = LedgerService(db)

        blocks = []
        for i in range(5):
            block = await ls.append_block(f"ACTION_{i}", f"ev{i}", f"hash{i}")
            blocks.append(block)

        for i, block in enumerate(blocks):
            assert block["block_no"] == i + 1

    @pytest.mark.asyncio
    async def test_hash_computation(self):
        """Block hash must be SHA-256 of concatenated fields."""
        from services.ledger_service import LedgerService

        db = MockDB()
        ls = LedgerService(db)

        block = await ls.append_block("TEST_ACTION", "ev123", "datahash456")

        # Recompute hash
        raw = (
            str(block["block_no"])
            + block["timestamp"]
            + block["action"]
            + block["evidence_id"]
            + block["data_hash"]
            + block["previous_hash"]
        )
        expected = hashlib.sha256(raw.encode()).hexdigest()
        assert block["current_hash"] == expected


# ══════════════════════════════════════════════════
# AUDIT SERVICE TESTS
# ══════════════════════════════════════════════════

class TestAuditService:
    """Tests for audit service."""

    @pytest.mark.asyncio
    async def test_log_action_creates_audit_and_ledger(self):
        """log_action must create both audit log and ledger block."""
        from services.ledger_service import LedgerService
        from services.audit_service import AuditService

        db = MockDB()
        ls = LedgerService(db)
        audit = AuditService(db, ls)

        await audit.log_action(
            case_id="case1",
            evidence_id="ev1",
            action="EVIDENCE_ACQUIRED",
            actor="TestInvestigator",
            details={"filename": "test.mp4"},
            result="SUCCESS",
        )

        # Check audit log was created
        audit_count = await db.audit_logs.count_documents({})
        assert audit_count == 1

        # Check ledger block was created
        ledger_count = await db.ledger_blocks.count_documents({})
        assert ledger_count == 1

    @pytest.mark.asyncio
    async def test_multiple_actions_create_valid_chain(self):
        """Multiple audit actions should produce a valid ledger chain."""
        from services.ledger_service import LedgerService
        from services.audit_service import AuditService

        db = MockDB()
        ls = LedgerService(db)
        audit = AuditService(db, ls)

        for i in range(5):
            await audit.log_action(
                case_id="case1",
                evidence_id=f"ev{i}",
                action=f"ACTION_{i}",
                actor="TestInvestigator",
                details={"step": i},
                result="SUCCESS",
            )

        result = await ls.verify_chain()
        assert result["valid"] is True


# ══════════════════════════════════════════════════
# TIMELINE CLUSTERING TESTS
# ══════════════════════════════════════════════════

class TestTimelineClustering:
    """Tests for cross-camera event correlation."""

    @pytest.mark.asyncio
    async def test_events_within_window_clustered(self):
        """Events from different cameras within ±5s should be clustered."""
        from services.timeline_service import TimelineService

        db = MockDB()
        ts = TimelineService()

        case_id = "test_case"

        # Create evidence for 2 cameras
        await db.evidence.insert_one({
            "_id": "ev1", "case_id": case_id, "device_id": "dev1",
            "filename": "cam1.mp4"
        })
        await db.evidence.insert_one({
            "_id": "ev2", "case_id": case_id, "device_id": "dev2",
            "filename": "cam2.mp4"
        })

        # Create events within 5 seconds of each other, different cameras
        await db.analysis_events.insert_one({
            "_id": "e1", "evidence_id": "ev1", "case_id": case_id,
            "event_type": "motion", "timestamp_sec": 100.0,
            "duration_sec": 2.0, "confidence": 0.8,
            "details": {"camera": "CAM-01"}, "is_demo": True,
            "created_at": datetime.now(timezone.utc).isoformat()
        })
        await db.analysis_events.insert_one({
            "_id": "e2", "evidence_id": "ev2", "case_id": case_id,
            "event_type": "person", "timestamp_sec": 103.0,
            "duration_sec": 3.0, "confidence": 0.9,
            "details": {"camera": "CAM-02"}, "is_demo": True,
            "created_at": datetime.now(timezone.utc).isoformat()
        })

        result = await ts.get_timeline(db, case_id)

        assert len(result["incidents"]) >= 1
        incident = result["incidents"][0]
        assert len(incident["events"]) == 2

    @pytest.mark.asyncio
    async def test_distant_events_not_clustered(self):
        """Events far apart in time should not be clustered."""
        from services.timeline_service import TimelineService

        db = MockDB()
        ts = TimelineService()

        case_id = "test_case"

        await db.evidence.insert_one({
            "_id": "ev1", "case_id": case_id, "device_id": "dev1",
            "filename": "cam1.mp4"
        })
        await db.evidence.insert_one({
            "_id": "ev2", "case_id": case_id, "device_id": "dev2",
            "filename": "cam2.mp4"
        })

        await db.analysis_events.insert_one({
            "_id": "e1", "evidence_id": "ev1", "case_id": case_id,
            "event_type": "motion", "timestamp_sec": 100.0,
            "duration_sec": 2.0, "confidence": 0.8,
            "details": {}, "is_demo": True,
            "created_at": datetime.now(timezone.utc).isoformat()
        })
        await db.analysis_events.insert_one({
            "_id": "e2", "evidence_id": "ev2", "case_id": case_id,
            "event_type": "motion", "timestamp_sec": 200.0,
            "duration_sec": 2.0, "confidence": 0.8,
            "details": {}, "is_demo": True,
            "created_at": datetime.now(timezone.utc).isoformat()
        })

        result = await ts.get_timeline(db, case_id)
        assert len(result["incidents"]) == 0

    @pytest.mark.asyncio
    async def test_same_camera_events_not_clustered(self):
        """Events from the same camera should not form an incident."""
        from services.timeline_service import TimelineService

        db = MockDB()
        ts = TimelineService()

        case_id = "test_case"

        await db.evidence.insert_one({
            "_id": "ev1", "case_id": case_id, "device_id": "dev1",
            "filename": "cam1.mp4"
        })

        await db.analysis_events.insert_one({
            "_id": "e1", "evidence_id": "ev1", "case_id": case_id,
            "event_type": "motion", "timestamp_sec": 100.0,
            "duration_sec": 2.0, "confidence": 0.8,
            "details": {}, "is_demo": True,
            "created_at": datetime.now(timezone.utc).isoformat()
        })
        await db.analysis_events.insert_one({
            "_id": "e2", "evidence_id": "ev1", "case_id": case_id,
            "event_type": "person", "timestamp_sec": 102.0,
            "duration_sec": 3.0, "confidence": 0.9,
            "details": {}, "is_demo": True,
            "created_at": datetime.now(timezone.utc).isoformat()
        })

        result = await ts.get_timeline(db, case_id)
        # Same camera events should NOT form cross-camera incidents
        assert len(result["incidents"]) == 0


# ══════════════════════════════════════════════════
# RUN
# ══════════════════════════════════════════════════

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
