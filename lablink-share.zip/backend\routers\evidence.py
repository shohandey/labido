from fastapi import APIRouter, Depends, Request, Response, Header, HTTPException
from fastapi.responses import FileResponse
from bson import ObjectId
import os
import aiofiles
from datetime import datetime
from dependencies import get_db, get_audit_service, get_ledger_service
from services.hashing import calculate_sha256, verify_hash
from models.models import BookmarkCreate, Bookmark, AnnotationCreate, Annotation

router = APIRouter(prefix="/evidence", tags=["evidence"])

@router.get("")
async def list_evidence(case_id: str = None, db = Depends(get_db)):
    query = {"case_id": case_id} if case_id else {}
    cursor = db.evidence.find(query).sort("created_at", -1)
    results = await cursor.to_list(length=100)
    for r in results:
        r["_id"] = str(r["_id"])
    return results

@router.get("/{evidence_id}")
async def get_evidence(evidence_id: str, db = Depends(get_db)):
    e = await db.evidence.find_one({"_id": ObjectId(evidence_id)})
    if e:
        e["_id"] = str(e["_id"])
        device = await db.devices.find_one({"_id": ObjectId(e["device_id"])})
        if device:
            device["_id"] = str(device["_id"])
            e["device"] = device
    return e

@router.post("/{evidence_id}/hash")
async def update_hash(
    evidence_id: str,
    db = Depends(get_db),
    audit_service = Depends(get_audit_service)
):
    e = await db.evidence.find_one({"_id": ObjectId(evidence_id)})
    if not e:
        raise HTTPException(404, "Evidence not found")
        
    new_hash = await calculate_sha256(e["original_path"])
    await db.evidence.update_one({"_id": ObjectId(evidence_id)}, {"$set": {"sha256": new_hash}})
    
    await audit_service.log_action(
        e["case_id"], str(e["_id"]), "HASH_RECALCULATED", "System",
        {"old_hash": e.get("sha256"), "new_hash": new_hash}, "SUCCESS"
    )
    return {"sha256": new_hash}

@router.post("/{evidence_id}/verify")
async def verify_evidence_hash(
    evidence_id: str,
    db = Depends(get_db),
    audit_service = Depends(get_audit_service)
):
    e = await db.evidence.find_one({"_id": ObjectId(evidence_id)})
    if not e:
        raise HTTPException(404, "Evidence not found")
        
    result = await verify_hash(e["original_path"], e["sha256"])
    
    await audit_service.log_action(
        e["case_id"], str(e["_id"]), "HASH_VERIFIED", "System",
        result, "SUCCESS" if result["match"] else "FAILED"
    )
    return result

@router.get("/{evidence_id}/stream")
async def stream_video(evidence_id: str, request: Request, range: str = Header(None), db = Depends(get_db)):
    e = await db.evidence.find_one({"_id": ObjectId(evidence_id)})
    if not e:
        raise HTTPException(404)
        
    path = e["working_path"]
    if not os.path.exists(path):
        raise HTTPException(404)
        
    file_size = os.path.getsize(path)
    if range:
        range_str = range.replace("bytes=", "").split("-")
        start = int(range_str[0])
        end = int(range_str[1]) if range_str[1] else file_size - 1
        chunk_size = end - start + 1
        
        async def file_iterator():
            async with aiofiles.open(path, "rb") as f:
                await f.seek(start)
                bytes_read = 0
                while bytes_read < chunk_size:
                    chunk = await f.read(min(8192, chunk_size - bytes_read))
                    if not chunk:
                        break
                    bytes_read += len(chunk)
                    yield chunk
                    
        headers = {
            "Content-Range": f"bytes {start}-{end}/{file_size}",
            "Accept-Ranges": "bytes",
            "Content-Length": str(chunk_size),
            "Content-Type": "video/mp4",
        }
        from fastapi.responses import StreamingResponse
        return StreamingResponse(file_iterator(), status_code=206, headers=headers)
    else:
        return FileResponse(path)

@router.get("/{evidence_id}/thumbnail")
async def get_thumbnail(evidence_id: str, db = Depends(get_db)):
    e = await db.evidence.find_one({"_id": ObjectId(evidence_id)})
    if not e:
        raise HTTPException(404)
    # Default thumbnail logic, simplified
    thumb_path = os.path.join(os.path.dirname(e["working_path"]), f"thumb_{evidence_id}.jpg")
    if os.path.exists(thumb_path):
        return FileResponse(thumb_path)
    raise HTTPException(404)

@router.post("/{evidence_id}/bookmarks", response_model=Bookmark)
async def create_bookmark(evidence_id: str, bm: BookmarkCreate, db = Depends(get_db)):
    doc = bm.model_dump()
    doc["created_at"] = datetime.utcnow()
    res = await db.bookmarks.insert_one(doc)
    doc["_id"] = str(res.inserted_id)
    return doc

@router.get("/{evidence_id}/bookmarks")
async def list_bookmarks(evidence_id: str, db = Depends(get_db)):
    cursor = db.bookmarks.find({"evidence_id": evidence_id})
    res = await cursor.to_list(100)
    for r in res: r["_id"] = str(r["_id"])
    return res

@router.post("/{evidence_id}/annotations", response_model=Annotation)
async def create_annotation(evidence_id: str, an: AnnotationCreate, db = Depends(get_db)):
    doc = an.model_dump()
    doc["created_at"] = datetime.utcnow()
    res = await db.annotations.insert_one(doc)
    doc["_id"] = str(res.inserted_id)
    return doc

@router.get("/{evidence_id}/annotations")
async def list_annotations(evidence_id: str, db = Depends(get_db)):
    cursor = db.annotations.find({"evidence_id": evidence_id})
    res = await cursor.to_list(100)
    for r in res: r["_id"] = str(r["_id"])
    return res
