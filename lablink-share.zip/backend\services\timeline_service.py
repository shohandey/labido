class TimelineService:
    CORRELATION_WINDOW = 5  # seconds
    
    async def get_timeline(self, db, case_id: str) -> dict:
        cursor = db["analysis_events"].find({"case_id": case_id}).sort("timestamp_sec", 1)
        events = await cursor.to_list(length=None)
        
        evidence_cursor = db["evidence"].find({"case_id": case_id})
        evidence_list = await evidence_cursor.to_list(length=None)
        evidence_map = {str(e["_id"]): e for e in evidence_list}
        
        for ev in events:
            ev["_id"] = str(ev["_id"])
            ev_id = ev.get("evidence_id")
            if ev_id in evidence_map:
                ev["camera_name"] = evidence_map[ev_id].get("metadata", {}).get("camera_name", "Unknown Camera")
                
        incidents = []
        used_events = set()
        for i, event in enumerate(events):
            if event["_id"] in used_events:
                continue
            cluster = [event]
            for j in range(i+1, len(events)):
                other = events[j]
                if other["_id"] in used_events:
                    continue
                if abs(other["timestamp_sec"] - event["timestamp_sec"]) <= self.CORRELATION_WINDOW:
                    if other.get("evidence_id") != event.get("evidence_id"):
                        cluster.append(other)
                        used_events.add(other["_id"])
                elif other["timestamp_sec"] - event["timestamp_sec"] > self.CORRELATION_WINDOW:
                    break
            if len(cluster) >= 2:
                used_events.add(event["_id"])
                incidents.append({
                    "id": f"INC-{len(incidents)+1:04d}",
                    "events": cluster,
                    "start_time": min(e["timestamp_sec"] for e in cluster),
                    "end_time": max(e["timestamp_sec"] for e in cluster)
                })
                
        return {"events": events, "incidents": incidents}
