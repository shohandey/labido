import os
import uuid
import datetime
from fastapi import APIRouter, HTTPException, BackgroundTasks, Request
from pydantic import BaseModel
from fastapi.responses import FileResponse
from backend.reports.generator import ForensicReportGenerator
import asyncio

router = APIRouter(prefix="/api/reports", tags=["Reports"])

class GenerateReportRequest(BaseModel):
    case_id: str

reports_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "reports_output")

# Store job status in memory for simplicity in this prototype
jobs = {}

async def process_report_job(job_id: str, case_id: str, db):
    try:
        generator = ForensicReportGenerator(db=db, case_id=case_id, output_dir=reports_dir)
        filepath = await generator.generate()
        jobs[job_id] = {"status": "completed", "report_path": filepath}
        
        # Add audit log
        audit_entry = {
            "id": str(uuid.uuid4()),
            "case_id": case_id,
            "action": "REPORT_GENERATED",
            "actor": "system",
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "details": f"Generated forensic report {os.path.basename(filepath)}"
        }
        await db.audit_logs.insert_one(audit_entry)
        
    except Exception as e:
        jobs[job_id] = {"status": "failed", "error": str(e)}

@router.post("/generate")
async def generate_report(req: GenerateReportRequest, background_tasks: BackgroundTasks, request: Request):
    db = request.app.state.db
    job_id = str(uuid.uuid4())
    jobs[job_id] = {"status": "processing"}
    background_tasks.add_task(process_report_job, job_id, req.case_id, db)
    return {"job_id": job_id, "message": "Report generation started"}

@router.get("/status/{job_id}")
async def get_report_status(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    return jobs[job_id]

@router.get("/{filename}")
async def get_report(filename: str):
    filepath = os.path.join(reports_dir, filename)
    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail="Report not found")
    return FileResponse(filepath, media_type="application/pdf", filename=filename)

@router.get("")
async def list_reports():
    if not os.path.exists(reports_dir):
        return []
    reports = []
    for f in os.listdir(reports_dir):
        if f.endswith(".pdf"):
            reports.append(f)
    return {"reports": reports}
