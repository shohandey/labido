from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from datetime import datetime
import os
import uuid
import re
import shutil
import aiofiles
from database import get_database
from dependencies import get_audit_service, get_metadata_service
from services.hashing import calculate_sha256
from config import get_settings

router = APIRouter(prefix="/acquisition", tags=["acquisition"])

def sanitize_filename(filename: str) -> str:
    return re.sub(r'[^a-zA-Z0-9_\-\.]', '_', filename)

@router.post("")
async def upload_evidence(
    file: UploadFile = File(...),
    case_id: str = Form(...),
    vendor: str = Form("generic"),
    device_name: str = Form(...),
    device_model: str = Form(None),
    device_serial: str = Form(None),
    device_location: str = Form(None),
    investigator: str = Form("System"),
    db = Depends(get_database),
    audit_service = Depends(get_audit_service),
    metadata_service = Depends(get_metadata_service)
):
    settings = get_settings()
    ext = file.filename.split('.')[-1].lower()
    allowed_exts = {'mp4', 'avi', 'mkv', 'mov', 'dav', 'h264', 'h265', 'bin', 'raw', 'dat'}
    if ext not in allowed_exts:
        raise HTTPException(400, "Unsupported file extension")

    safe_filename = sanitize_filename(file.filename)
    file_uuid = str(uuid.uuid4())
    stored_filename = f"{file_uuid}_{safe_filename}"
    
    orig_dir = os.path.join(settings.EVIDENCE_ROOT, "originals", case_id)
    work_dir = os.path.join(settings.EVIDENCE_ROOT, "working", case_id)
    os.makedirs(orig_dir, exist_ok=True)
    os.makedirs(work_dir, exist_ok=True)
    
    orig_path = os.path.join(orig_dir, stored_filename)
    work_path = os.path.join(work_dir, stored_filename)
    
    async with aiofiles.open(orig_path, 'wb') as out_file:
        while chunk := await file.read(8192):
            await out_file.write(chunk)
            
    sha256_hash = await calculate_sha256(orig_path)
    shutil.copy2(orig_path, work_path)
    file_size = os.path.getsize(orig_path)
    
    device_doc = {
        "case_id": case_id,
        "name": device_name,
        "vendor": vendor,
        "model": device_model,
        "serial": device_serial,
        "location": device_location
    }
    device_res = await db.devices.insert_one(device_doc)
    device_id = str(device_res.inserted_id)
    
    metadata = await metadata_service.extract_metadata(work_path)
    thumb_path = os.path.join(settings.EVIDENCE_ROOT, "thumbnails", f"{file_uuid}.jpg")
    os.makedirs(os.path.dirname(thumb_path), exist_ok=True)
    await metadata_service.generate_thumbnail(work_path, thumb_path)
    
    evidence_doc = {
        "case_id": case_id,
        "device_id": device_id,
        "filename": file.filename,
        "original_path": orig_path,
        "working_path": work_path,
        "sha256": sha256_hash,
        "status": "original",
        "vendor": vendor,
        "is_demo": False,
        "metadata": metadata,
        "file_size": file_size,
        "created_at": datetime.utcnow()
    }
    
    ev_res = await db.evidence.insert_one(evidence_doc)
    evidence_id = str(ev_res.inserted_id)
    evidence_doc["_id"] = evidence_id
    
    await audit_service.log_action(
        case_id, evidence_id, "EVIDENCE_ACQUIRED", investigator,
        {"filename": file.filename, "size": file_size, "hash": sha256_hash}, "SUCCESS"
    )
    
    return evidence_doc
