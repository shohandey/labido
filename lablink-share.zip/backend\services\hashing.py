import hashlib
import aiofiles
from datetime import datetime

async def calculate_sha256(filepath: str) -> str:
    sha256_hash = hashlib.sha256()
    async with aiofiles.open(filepath, "rb") as f:
        while chunk := await f.read(8192):
            sha256_hash.update(chunk)
    return sha256_hash.hexdigest()

async def verify_hash(filepath: str, expected_hash: str) -> dict:
    actual_hash = await calculate_sha256(filepath)
    return {
        "match": actual_hash == expected_hash,
        "expected": expected_hash,
        "actual": actual_hash,
        "verified_at": datetime.utcnow().isoformat()
    }
