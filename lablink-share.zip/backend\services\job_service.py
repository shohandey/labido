from datetime import datetime
from bson import ObjectId

class JobService:
    def __init__(self, db):
        self.db = db

    async def create_job(self, case_id: str, evidence_id: str, job_type: str) -> str:
        job = {
            "case_id": case_id,
            "evidence_id": evidence_id,
            "type": job_type,
            "status": "QUEUED",
            "progress": 0,
            "message": "",
            "result": None,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
        res = await self.db.processing_jobs.insert_one(job)
        return str(res.inserted_id)

    async def update_job(self, job_id: str, status: str, progress: int, message: str, result: dict = None):
        update_data = {
            "status": status,
            "progress": progress,
            "message": message,
            "updated_at": datetime.utcnow()
        }
        if result is not None:
            update_data["result"] = result
            
        await self.db.processing_jobs.update_one(
            {"_id": ObjectId(job_id)},
            {"$set": update_data}
        )

    async def get_job(self, job_id: str) -> dict:
        job = await self.db.processing_jobs.find_one({"_id": ObjectId(job_id)})
        if job:
            job["_id"] = str(job["_id"])
        return job
