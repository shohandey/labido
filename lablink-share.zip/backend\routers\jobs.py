from fastapi import APIRouter, Request, HTTPException

router = APIRouter(prefix="/api/jobs", tags=["jobs"])

@router.get("/{job_id}")
async def get_job(job_id: str, request: Request):
    job_service = request.app.state.job_service
    job = await job_service.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job
