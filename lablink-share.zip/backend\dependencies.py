from fastapi import Request

def get_db(request: Request):
    return request.app.state.db

def get_audit_service(request: Request):
    return request.app.state.audit_service

def get_ledger_service(request: Request):
    return request.app.state.ledger_service

def get_job_service(request: Request):
    return request.app.state.job_service

def get_metadata_service(request: Request):
    return request.app.state.metadata_service
