import os
import re
from .base import VendorAdapter

class HikvisionAdapter(VendorAdapter):
    vendor_name = 'hikvision'
    
    async def identify(self, filepath: str) -> bool:
        filename = os.path.basename(filepath).lower()
        if filename.endswith('.dav') or 'hikvision' in filename:
            return True
        return False
        
    async def parse_metadata(self, filepath: str) -> dict:
        metadata = {"vendor": self.vendor_name, "is_demo": True, "channels": []}
        filename = os.path.basename(filepath)
        match = re.search(r'ch(\d{2})_(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})', filename, re.IGNORECASE)
        if match:
            channel, year, month, day, hour, minute, second = match.groups()
            metadata["channels"].append(int(channel))
            metadata["start_time"] = f"{year}-{month}-{day}T{hour}:{minute}:{second}Z"
        return metadata
        
    def capabilities(self) -> set:
        return {'import', 'repair_stream', 'parse_index'}
