import os
import logging
from backend.recovery.stream_repair import StreamRepair

logger = logging.getLogger(__name__)

class FileCarver:
    SIGNATURES = {
        'mp4_ftyp': b'ftyp',
        'h264_nalu': b'\x00\x00\x00\x01',
        'h264_short_nalu': b'\x00\x00\x01',
    }
    
    def __init__(self):
        self.stream_repair = StreamRepair()
    
    async def carve(self, input_path: str, output_dir: str) -> dict:
        fragments = []
        items_found = 0
        os.makedirs(output_dir, exist_ok=True)
        try:
            with open(input_path, 'rb') as f:
                data = f.read(1024 * 1024 * 50)  # Read up to 50MB
            
            offset = 0
            while True:
                idx = data.find(self.SIGNATURES['mp4_ftyp'], offset)
                if idx == -1:
                    break
                items_found += 1
                start_idx = max(0, idx - 4)
                end_idx = min(len(data), start_idx + 5 * 1024 * 1024) # Carve up to 5MB
                chunk = data[start_idx:end_idx]
                out_path = os.path.join(output_dir, f'carved_{items_found}.mp4')
                with open(out_path, 'wb') as out_f:
                    out_f.write(chunk)
                
                repaired_path = os.path.join(output_dir, f'repaired_carved_{items_found}.mp4')
                repair_res = await self.stream_repair.repair(out_path, repaired_path)
                
                fragments.append({
                    "path": out_path,
                    "size": len(chunk),
                    "type": "mp4_ftyp",
                    "repaired": repair_res.get('success', False)
                })
                offset = idx + 4
                
            return {
                "success": True,
                "items_found": items_found,
                "fragments": fragments,
                "details": {"scan_method": "signature_scan", "signatures_searched": list(self.SIGNATURES.keys())}
            }
        except Exception as e:
            logger.error(f"Carving failed: {e}")
            return {"success": False, "error": str(e)}
