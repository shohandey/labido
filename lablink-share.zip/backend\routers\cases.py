from fastapi import APIRouter, Depends
from datetime import datetime
from bson import ObjectId
from database import get_database
from models.models import CaseCreate, Case

router = APIRouter(prefix="/cases", tags=["cases"])

@router.post("", response_model=Case)
async def create_case(case: CaseCreate, db = Depends(get_database)):
    doc = case.model_dump()
    doc["created_at"] = datetime.utcnow()
    doc["updated_at"] = datetime.utcnow()
    res = await db.cases.insert_one(doc)
    doc["_id"] = str(res.inserted_id)
    return doc

@router.get("")
async def list_cases(q: str = None, db = Depends(get_database)):
    query = {}
    if q:
        query = {"$or": [{"name": {"$regex": q, "$options": "i"}}, {"description": {"$regex": q, "$options": "i"}}]}
    
    cursor = db.cases.find(query).sort("created_at", -1)
    cases = await cursor.to_list(length=100)
    
    for c in cases:
        c["_id"] = str(c["_id"])
        c["evidence_count"] = await db.evidence.count_documents({"case_id": c["_id"]})
        c["device_count"] = await db.devices.count_documents({"case_id": c["_id"]})
    return cases

@router.get("/{case_id}")
async def get_case(case_id: str, db = Depends(get_database)):
    c = await db.cases.find_one({"_id": ObjectId(case_id)})
    if c:
        c["_id"] = str(c["_id"])
        c["evidence_count"] = await db.evidence.count_documents({"case_id": c["_id"]})
        c["device_count"] = await db.devices.count_documents({"case_id": c["_id"]})
    return c
