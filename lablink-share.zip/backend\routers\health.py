from fastapi import APIRouter, Depends
import shutil
from database import get_database

router = APIRouter()

@router.get("/health")
async def health_check(db = Depends(get_database)):
    status = {
        "status": "ok",
        "mongodb": False,
        "ffmpeg": shutil.which("ffmpeg") is not None,
        "ffprobe": shutil.which("ffprobe") is not None,
        "opencv": False
    }
    try:
        await db.command("ping")
        status["mongodb"] = True
    except:
        pass
        
    try:
        import cv2
        status["opencv"] = True
    except ImportError:
        pass
        
    return status
