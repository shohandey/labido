from motor.motor_asyncio import AsyncIOMotorClient
import logging

logger = logging.getLogger(__name__)

db_client: AsyncIOMotorClient = None
db = None

async def init_db(app):
    global db_client, db
    from .config import get_settings
    settings = get_settings()
    db_client = AsyncIOMotorClient(settings.MONGO_URI)
    try:
        await db_client.admin.command('ping')
        logger.info("Connected to MongoDB")
    except Exception as e:
        logger.error(f"Could not connect to MongoDB: {e}")
        raise
    db = db_client[settings.DATABASE_NAME]
    app.state.db = db
    await create_indexes()

def get_database():
    return db

async def create_indexes():
    await db.ledger_blocks.create_index("block_no", unique=True)
    await db.analysis_events.create_index([("case_id", 1), ("timestamp_sec", 1)])
    await db.evidence.create_index("case_id")
    await db.audit_logs.create_index([("case_id", 1), ("created_at", 1)])
    await db.recovery_results.create_index("evidence_id")
    await db.cases.create_index("created_at")
    await db.evidence.create_index("sha256")
    await db.analysis_events.create_index("evidence_id")
    await db.processing_jobs.create_index("status")
