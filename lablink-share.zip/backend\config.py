from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    MONGO_URI: str = "mongodb://localhost:27017"
    DATABASE_NAME: str = "pramaansync"
    EVIDENCE_ROOT: str = "./evidence"
    REPORT_ROOT: str = "./reports"
    MAX_UPLOAD_MB: int = 500

    class Config:
        env_file = "../.env"

@lru_cache
def get_settings():
    return Settings()
