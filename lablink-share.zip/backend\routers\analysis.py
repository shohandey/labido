from fastapi import APIRouter, Request, HTTPException, BackgroundTasks
from pydantic import BaseModel
import cv2
import time
from backend.database import get_database
from backend.detectors.yolo import get_detector

router = APIRouter(prefix="/api/analysis", tags=["analysis"])

class AnalysisRequest(BaseModel):
    evidence_id: str
    case_id: str

async def run_analysis_task(app_state, req: AnalysisRequest, job_id: str):
    db = await get_database()
    evidence = await db["evidence"].find_one({"_id": req.evidence_id})
    if not evidence:
        return
        
    filepath = evidence.get("filepath", "")
    job_service = app_state.job_service
    detector = get_detector()
    
    cap = cv2.VideoCapture(filepath)
    if not cap.isOpened():
        await job_service.update_job(job_id, status='failed', message='Failed to open video')
        return
        
    fgbg = cv2.createBackgroundSubtractorMOG2()
    
    events = []
    frame_count = 0
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    await job_service.update_job(job_id, progress=0, message='Starting analysis...')
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        frame_count += 1
        timestamp_sec = frame_count / fps
        
        # Sample every ~1 second
        if frame_count % int(fps) != 0:
            continue
            
        fgmask = fgbg.apply(frame)
        motion_ratio = cv2.countNonZero(fgmask) / (frame.shape[0] * frame.shape[1])
        
        has_motion = motion_ratio > 0.05
        detections = detector.detect(frame)
        
        if has_motion or detections:
            event = {
                "evidence_id": req.evidence_id,
                "case_id": req.case_id,
                "timestamp_sec": timestamp_sec,
                "event_type": "motion" if has_motion else "detection",
                "details": {
                    "motion_ratio": float(motion_ratio),
                    "detections": detections
                },
                "is_demo": detector.get_mode() == 'demo'
            }
            events.append(event)
            
            if len(events) >= 50:
                await db["analysis_events"].insert_many(events)
                events = []
                
        if frame_count % (int(fps) * 10) == 0:
            progress = int((frame_count / total_frames) * 100) if total_frames > 0 else 50
            await job_service.update_job(job_id, progress=progress, message=f'Analyzing... {progress}%')
            
    if events:
        await db["analysis_events"].insert_many(events)
        
    cap.release()
    await job_service.update_job(job_id, progress=100, status='completed', message='Analysis complete')
    if app_state.audit_service:
        await app_state.audit_service.log_event("analysis_completed", req.evidence_id)

@router.post("")
async def start_analysis(req: AnalysisRequest, request: Request, background_tasks: BackgroundTasks):
    job_service = request.app.state.job_service
    job_id = await job_service.create_job("analysis", {"evidence_id": req.evidence_id, "case_id": req.case_id})
    background_tasks.add_task(run_analysis_task, request.app.state, req, job_id)
    return {"job_id": job_id, "message": "Analysis started"}
