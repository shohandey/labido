from datetime import datetime
import hashlib
import json

class AuditService:
    def __init__(self, db, ledger_service):
        self.db = db
        self.ledger_service = ledger_service

    async def log_action(self, case_id: str, evidence_id: str, action: str, actor: str, details: dict, result: str) -> dict:
        log_entry = {
            "case_id": case_id,
            "evidence_id": evidence_id,
            "action": action,
            "actor": actor,
            "details": details,
            "result": result,
            "created_at": datetime.utcnow()
        }
        res = await self.db.audit_logs.insert_one(log_entry)
        log_entry["_id"] = str(res.inserted_id)
        
        details_str = json.dumps(details, sort_keys=True)
        data_hash = hashlib.sha256(details_str.encode('utf-8')).hexdigest()
        await self.ledger_service.append_block(action, evidence_id or '', data_hash)
        
        return log_entry

    async def get_logs(self, case_id: str, skip: int = 0, limit: int = 100):
        query = {"case_id": case_id} if case_id else {}
        cursor = self.db.audit_logs.find(query).sort("created_at", -1).skip(skip).limit(limit)
        logs = await cursor.to_list(length=limit)
        for log in logs:
            log["_id"] = str(log["_id"])
        return logs
