/**
 * LabLink — Alternative Suggestion Engine
 *
 * When a booking conflicts or equipment is unavailable, this module
 * generates meaningful, human-readable suggestions rather than random picks.
 *
 * Strategy:
 *   1. Same equipment → find available time slots on the requested date
 *   2. Same equipment → find available time slots on the next 3 days
 *   3. Compatible equipment → find any availability on requested date or next 3 days
 */

import { findAvailableSlots, formatTimeRange } from './conflicts.js';

const addDays = (dateStr, n) => {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + n);
  return d.toISOString().split('T')[0];
};

const fmtDate = (dateStr) => {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'long', month: 'short', day: 'numeric' });
};

/**
 * Generate up to 3 meaningful alternative suggestions.
 *
 * @param {Array}  allEquipment  - full equipment catalog
 * @param {Array}  bookings      - all current bookings
 * @param {object} request       - the failed/conflicting request
 *   { equipmentId, date, startTime, endTime, deadline }
 * @returns {Array<{ type, equipmentId, equipmentName, date, startTime, endTime, explanation }>}
 */
export function getSuggestions(allEquipment, bookings, request) {
  const { equipmentId, date, startTime, endTime, deadline } = request;
  const reqDuration =
    (parseInt(endTime.split(':')[0]) * 60 + parseInt(endTime.split(':')[1])) -
    (parseInt(startTime.split(':')[0]) * 60 + parseInt(startTime.split(':')[1]));

  const suggestions = [];
  const deadlineDate = deadline || addDays(date, 7);

  const equipment = allEquipment.find((e) => e.id === equipmentId);
  if (!equipment) return suggestions;

  // ── 1. Same equipment, same day, different time ──────────────────────────
  const sameEqSameDay = findAvailableSlots(bookings, equipmentId, date, reqDuration);
  if (sameEqSameDay.length > 0) {
    const slot = sameEqSameDay[0];
    suggestions.push({
      type: 'same-equipment-different-time',
      equipmentId,
      equipmentName: equipment.name,
      emoji: equipment.emoji,
      lab: equipment.lab,
      date,
      startTime: slot.startTime,
      endTime: slot.endTime,
      explanation: `${equipment.name} is already booked during your chosen time, but it's free on ${fmtDate(date)} from ${formatTimeRange(slot.startTime, slot.endTime)}.`,
    });
  }

  // ── 2. Same equipment, next 3 days ───────────────────────────────────────
  if (suggestions.length < 2) {
    for (let d = 1; d <= 3 && suggestions.length < 2; d++) {
      const nextDate = addDays(date, d);
      if (nextDate > deadlineDate) break;
      const slots = findAvailableSlots(bookings, equipmentId, nextDate, reqDuration);
      if (slots.length > 0) {
        const slot = slots[0];
        suggestions.push({
          type: 'same-equipment-different-day',
          equipmentId,
          equipmentName: equipment.name,
          emoji: equipment.emoji,
          lab: equipment.lab,
          date: nextDate,
          startTime: slot.startTime,
          endTime: slot.endTime,
          explanation: `The same ${equipment.name} is available on ${fmtDate(nextDate)} from ${formatTimeRange(slot.startTime, slot.endTime)}, which is still before your deadline.`,
        });
      }
    }
  }

  // ── 3. Compatible equipment (same tags or compatibleWith list) ───────────
  if (suggestions.length < 3 && equipment.compatibleWith?.length > 0) {
    const compatibleEq = allEquipment.filter(
      (e) => e.id !== equipmentId && equipment.compatibleWith.includes(e.id) && e.available > 0
    );

    for (const alt of compatibleEq) {
      if (suggestions.length >= 3) break;

      // Check on requested date first
      let altDate = date;
      let altSlots = findAvailableSlots(bookings, alt.id, altDate, reqDuration);

      if (altSlots.length === 0) {
        // Try next 3 days
        for (let d = 1; d <= 3; d++) {
          const nextDate = addDays(date, d);
          if (nextDate > deadlineDate) break;
          altSlots = findAvailableSlots(bookings, alt.id, nextDate, reqDuration);
          if (altSlots.length > 0) {
            altDate = nextDate;
            break;
          }
        }
      }

      if (altSlots.length > 0) {
        const slot = altSlots[0];
        const isSameDay = altDate === date;
        suggestions.push({
          type: 'alternative-equipment',
          equipmentId: alt.id,
          equipmentName: alt.name,
          emoji: alt.emoji,
          lab: alt.lab,
          date: altDate,
          startTime: slot.startTime,
          endTime: slot.endTime,
          explanation: isSameDay
            ? `${alt.name} in ${alt.lab.split('—')[0].trim()} is a compatible alternative and is available on ${fmtDate(altDate)} from ${formatTimeRange(slot.startTime, slot.endTime)}.`
            : `${alt.name} is a compatible alternative. It's free on ${fmtDate(altDate)} from ${formatTimeRange(slot.startTime, slot.endTime)}, still before your project deadline.`,
        });
      }
    }
  }

  // ── 4. Similar tags fallback ─────────────────────────────────────────────
  if (suggestions.length < 2) {
    const tagSimilar = allEquipment.filter(
      (e) =>
        e.id !== equipmentId &&
        e.available > 0 &&
        e.tags.some((t) => equipment.tags.includes(t)) &&
        !suggestions.find((s) => s.equipmentId === e.id)
    );

    for (const alt of tagSimilar) {
      if (suggestions.length >= 3) break;
      const altSlots = findAvailableSlots(bookings, alt.id, date, reqDuration);
      if (altSlots.length > 0) {
        const slot = altSlots[0];
        suggestions.push({
          type: 'similar-equipment',
          equipmentId: alt.id,
          equipmentName: alt.name,
          emoji: alt.emoji,
          lab: alt.lab,
          date,
          startTime: slot.startTime,
          endTime: slot.endTime,
          explanation: `${alt.name} shares similar capabilities and is available on ${fmtDate(date)} from ${formatTimeRange(slot.startTime, slot.endTime)}.`,
        });
      }
    }
  }

  return suggestions.slice(0, 3);
}
