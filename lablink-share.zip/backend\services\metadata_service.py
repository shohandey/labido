import subprocess
import json
import asyncio
import os

class MetadataService:
    async def extract_metadata(self, filepath: str) -> dict:
        cmd = [
            "ffprobe", "-v", "quiet", "-print_format", "json",
            "-show_format", "-show_streams", filepath
        ]
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            stdout, _ = await process.communicate()
            data = json.loads(stdout)
            
            video_stream = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), None)
            fmt = data.get("format", {})
            
            metadata = {}
            if video_stream:
                metadata["codec"] = video_stream.get("codec_name")
                width = video_stream.get("width")
                height = video_stream.get("height")
                if width and height:
                    metadata["resolution"] = f"{width}x{height}"
                fps_str = video_stream.get("r_frame_rate", "0/1")
                try:
                    num, den = map(int, fps_str.split('/'))
                    metadata["fps"] = num / den if den != 0 else 0
                except:
                    pass
                try:
                    metadata["frame_count"] = int(video_stream.get("nb_frames", 0))
                except:
                    pass
            
            if "duration" in fmt:
                try:
                    metadata["duration"] = float(fmt["duration"])
                except:
                    pass
            
            if "bit_rate" in fmt:
                try:
                    metadata["bitrate"] = int(fmt["bit_rate"])
                except:
                    pass
                    
            return metadata
        except Exception:
            return {}

    async def generate_thumbnail(self, filepath: str, output_path: str, timestamp: float = 1.0) -> str:
        cmd = [
            "ffmpeg", "-y", "-i", filepath,
            "-ss", str(timestamp),
            "-vframes", "1",
            "-vf", "scale=-1:360",
            "-q:v", "2",
            output_path
        ]
        process = await asyncio.create_subprocess_exec(
            *cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        await process.communicate()
        return output_path

    async def generate_thumbnails(self, filepath: str, output_dir: str, interval: float = 10.0) -> list:
        meta = await self.extract_metadata(filepath)
        duration = meta.get("duration", 0)
        tasks = []
        paths = []
        os.makedirs(output_dir, exist_ok=True)
        t = 0.0
        while t < duration:
            out_path = os.path.join(output_dir, f"thumb_{t}.jpg")
            paths.append(out_path)
            tasks.append(self.generate_thumbnail(filepath, out_path, t))
            t += interval
        if tasks:
            await asyncio.gather(*tasks)
        return paths
