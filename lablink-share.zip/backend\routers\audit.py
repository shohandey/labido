from fastapi import APIRouter, Depends
from dependencies import get_audit_service

router = APIRouter(prefix="/audit", tags=["audit"])

@router.get("")
async def list_audit_logs(case_id: str = None, skip: int = 0, limit: int = 100, audit_service = Depends(get_audit_service)):
    return await audit_service.get_logs(case_id, skip, limit)
