import os
from pathlib import Path
from backend.recovery.stream_repair import StreamRepair
from backend.recovery.file_carver import FileCarver
from backend.recovery.index_parser import IndexParser

class RecoveryEngine:
    def __init__(self):
        self.stream_repair = StreamRepair()
        self.file_carver = FileCarver()
        self.index_parser = IndexParser()
    
    async def run_recovery(self, evidence_id: str, filepath: str, vendor: str, output_dir: str, job_service=None, job_id: str=None) -> list[dict]:
        results = []
        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        filename = os.path.basename(filepath)
        
        if job_service and job_id:
            await job_service.update_job(job_id, progress=20, message='Running stream repair...')
        repair_output = str(out_dir / f'repaired_{filename}')
        repair_result = await self.stream_repair.repair(filepath, repair_output)
        results.append({"method": "stream_repair", **repair_result})
        
        if job_service and job_id:
            await job_service.update_job(job_id, progress=50, message='Scanning for fragments...')
        carve_dir = str(out_dir / 'carved')
        carve_result = await self.file_carver.carve(filepath, carve_dir)
        results.append({"method": "file_carve", **carve_result})
        
        if job_service and job_id:
            await job_service.update_job(job_id, progress=80, message='Parsing vendor index...')
        index_result = await self.index_parser.parse(filepath, vendor)
        results.append({"method": "vendor_index", **index_result})
        
        if job_service and job_id:
            await job_service.update_job(job_id, progress=100, message='Recovery complete', status='completed', result=results)
            
        return results
