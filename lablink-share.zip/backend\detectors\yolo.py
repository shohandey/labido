import os
import numpy as np
from .base import Detector
from .demo import DemoDetector

class YoloDetector(Detector):
    MODEL_PATH = os.path.join(os.path.dirname(__file__), 'yolov8n.onnx')
    
    def __init__(self):
        if not os.path.exists(self.MODEL_PATH):
            raise FileNotFoundError('ONNX model not found')
        import onnxruntime as ort
        self.session = ort.InferenceSession(self.MODEL_PATH)
        self.classes = ['person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat', 'traffic light'] # Simplified
        
    def detect(self, frame: np.ndarray) -> list[dict]:
        import cv2
        img = cv2.resize(frame, (640, 640))
        img = img.transpose((2, 0, 1))[np.newaxis, ...] / 255.0
        img = img.astype(np.float32)
        outputs = self.session.run(None, {self.session.get_inputs()[0].name: img})
        detections = []
        # Simplified post-processing for mock
        return detections
        
    def get_mode(self) -> str:
        return 'yolo'

def get_detector() -> Detector:
    try:
        return YoloDetector()
    except (FileNotFoundError, ImportError):
        return DemoDetector()
