import numpy as np
import random
from .base import Detector

class DemoDetector(Detector):
    def __init__(self):
        self.frame_count = 0
        self.pool = ['person', 'vehicle', 'motion', 'face', 'bag']
        
    def detect(self, frame: np.ndarray) -> list[dict]:
        self.frame_count += 1
        detections = []
        if self.frame_count % 30 == 0:
            num_dets = random.randint(1, 2)
            for _ in range(num_dets):
                label = random.choice(self.pool)
                conf = random.uniform(0.65, 0.95)
                h, w = frame.shape[:2]
                x1 = random.randint(0, int(w * 0.8))
                y1 = random.randint(0, int(h * 0.8))
                x2 = random.randint(x1 + 10, w)
                y2 = random.randint(y1 + 10, h)
                detections.append({
                    "label": label,
                    "confidence": conf,
                    "bbox": [x1, y1, x2, y2],
                    "is_demo": True
                })
        return detections
        
    def get_mode(self) -> str:
        return 'demo'
