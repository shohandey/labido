import os
import datetime
from motor.motor_asyncio import AsyncIOMotorDatabase
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, mm
from reportlab.lib.colors import HexColor, lightgrey, white, black
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.platypus.tableofcontents import TableOfContents

class ForensicReportGenerator:
    def __init__(self, db: AsyncIOMotorDatabase, case_id: str, output_dir: str):
        self.db = db
        self.case_id = case_id
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        self.styles = getSampleStyleSheet()
        self.styles.add(ParagraphStyle(name='Title', parent=self.styles['Heading1'], alignment=TA_CENTER, fontSize=24, spaceAfter=20, fontName='Helvetica-Bold'))
        self.styles.add(ParagraphStyle(name='Subtitle', parent=self.styles['Heading2'], alignment=TA_CENTER, fontSize=16, spaceAfter=40))
        self.styles.add(ParagraphStyle(name='Watermark', alignment=TA_CENTER, fontSize=30, textColor=HexColor('#e0e0e0'), fontName='Helvetica-Bold'))
        self.styles.add(ParagraphStyle(name='Mono', parent=self.styles['Normal'], fontName='Courier', fontSize=8))
        self.styles.add(ParagraphStyle(name='SectionHeader', parent=self.styles['Heading2'], fontSize=14, spaceBefore=15, spaceAfter=10, fontName='Helvetica-Bold'))
        
        self.story = []

    def _header_footer(self, canvas, doc):
        canvas.saveState()
        # Header
        canvas.setFont('Helvetica-Bold', 10)
        canvas.setFillColor(HexColor('#ff0000'))
        canvas.drawString(inch, A4[1] - 0.5 * inch, "CONFIDENTIAL")
        
        # Footer
        canvas.setFont('Helvetica', 8)
        canvas.setFillColor(black)
        footer_text = f"PramaanSync Prototype | Demo/AI-generated findings are marked is_demo=True and require human validation. | Page {doc.page}"
        canvas.drawString(inch, 0.5 * inch, footer_text)
        canvas.restoreState()

    def _add_table(self, data, col_widths=None):
        if not data:
            return
        t = Table(data, colWidths=col_widths)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#4a4a4a')),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), white),
            ('GRID', (0, 0), (-1, -1), 1, HexColor('#e0e0e0')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, lightgrey])
        ]))
        self.story.append(t)
        self.story.append(Spacer(1, 10))

    async def generate(self) -> str:
        # 1. Fetch Data
        case = await self.db.cases.find_one({"id": self.case_id}) or {}
        devices = await self.db.devices.find({"case_id": self.case_id}).to_list(None)
        evidence = await self.db.evidence.find({"case_id": self.case_id}).to_list(None)
        recovery_results = await self.db.recovery_results.find({"case_id": self.case_id}).to_list(None)
        analysis_events = await self.db.analysis_events.find({"case_id": self.case_id}).to_list(None)
        audit_logs = await self.db.audit_logs.find({"case_id": self.case_id}).sort("timestamp", 1).to_list(None)
        ledger_blocks = await self.db.ledger_blocks.find({"case_id": self.case_id}).sort("timestamp", 1).to_list(None)
        annotations = await self.db.annotations.find({"case_id": self.case_id}).to_list(None)
        bookmarks = await self.db.bookmarks.find({"case_id": self.case_id}).to_list(None)

        # Build PDF synchronously
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.case_id}_forensic_report_{timestamp}.pdf"
        filepath = os.path.join(self.output_dir, filename)
        
        doc = SimpleDocTemplate(filepath, pagesize=A4, rightMargin=inch, leftMargin=inch, topMargin=inch, bottomMargin=inch)
        
        # 1. COVER PAGE
        self.story.append(Spacer(1, 2*inch))
        self.story.append(Paragraph("FORENSIC ANALYSIS REPORT", self.styles['Title']))
        self.story.append(Paragraph("Digital Surveillance Evidence Report", self.styles['Subtitle']))
        self.story.append(Spacer(1, inch))
        self.story.append(Paragraph("CONFIDENTIAL", self.styles['Watermark']))
        self.story.append(Spacer(1, inch))
        self.story.append(Paragraph(f"Case ID: {self.case_id}", self.styles['Normal']))
        self.story.append(Paragraph(f"Case Name: {case.get('name', 'N/A')}", self.styles['Normal']))
        self.story.append(Paragraph(f"Date Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", self.styles['Normal']))
        self.story.append(Paragraph(f"Investigator: {case.get('investigator', 'Lead Forensic Investigator')}", self.styles['Normal']))
        self.story.append(Spacer(1, inch))
        self.story.append(Paragraph("PramaanSync", self.styles['Heading3']))
        self.story.append(PageBreak())

        # 2. TABLE OF CONTENTS
        toc = TableOfContents()
        toc.levelStyles = [
            ParagraphStyle(fontName='Helvetica-Bold', fontSize=12, name='TOCHeading1', leftIndent=20, firstLineIndent=-20, spaceBefore=5, leading=16),
            ParagraphStyle(fontName='Helvetica', fontSize=10, name='TOCHeading2', leftIndent=40, firstLineIndent=-20, spaceBefore=3, leading=12),
        ]
        self.story.append(Paragraph("Table of Contents", self.styles['Title']))
        # ReportLab TOC takes multiple passes to build properly. We'll skip complex TOC for now.
        self.story.append(Paragraph("Sections:", self.styles['Heading2']))
        sections = [
            "1. Cover Page", "2. Table of Contents", "3. Case Information", "4. Investigator",
            "5. Devices", "6. Acquisition", "7. Evidence Hashes", "8. Metadata", "9. Recovery Results",
            "10. Analysis Findings", "11. Timeline", "12. Cross-Camera Correlation",
            "13. Investigator Annotations", "14. Chain of Custody", "15. Ledger Verification", "16. Disclaimer"
        ]
        for sec in sections:
            self.story.append(Paragraph(sec, self.styles['Normal']))
        self.story.append(PageBreak())

        # 3. CASE INFORMATION
        self.story.append(Paragraph("3. Case Information", self.styles['SectionHeader']))
        self.story.append(Paragraph(f"<b>Case ID:</b> {self.case_id}", self.styles['Normal']))
        self.story.append(Paragraph(f"<b>Name:</b> {case.get('name', 'N/A')}", self.styles['Normal']))
        self.story.append(Paragraph(f"<b>Description:</b> {case.get('description', 'N/A')}", self.styles['Normal']))
        self.story.append(Paragraph(f"<b>Created:</b> {case.get('created_at', 'N/A')}", self.styles['Normal']))
        self.story.append(Paragraph(f"<b>Total Evidence Items:</b> {len(evidence)}", self.styles['Normal']))
        self.story.append(Paragraph(f"<b>Total Devices:</b> {len(devices)}", self.styles['Normal']))
        self.story.append(Spacer(1, 10))

        # 4. INVESTIGATOR
        self.story.append(Paragraph("4. Investigator", self.styles['SectionHeader']))
        self.story.append(Paragraph(f"<b>Name:</b> {case.get('investigator', 'Unknown')}", self.styles['Normal']))
        self.story.append(Paragraph(f"<b>Role:</b> Lead Forensic Investigator", self.styles['Normal']))
        self.story.append(Paragraph(f"<b>Report Generated:</b> {datetime.datetime.now().isoformat()}", self.styles['Normal']))
        self.story.append(Spacer(1, 10))

        # 5. DEVICES
        self.story.append(Paragraph("5. Devices", self.styles['SectionHeader']))
        device_data = [["Name", "Vendor", "Model", "Serial", "Location"]]
        for d in devices:
            device_data.append([d.get("name", ""), d.get("vendor", ""), d.get("model", ""), d.get("serial", ""), d.get("location", "")])
        self._add_table(device_data)

        # 6. ACQUISITION
        self.story.append(Paragraph("6. Acquisition", self.styles['SectionHeader']))
        acq_data = [["Filename", "Vendor", "Acq. Date", "Method", "Status"]]
        for e in evidence:
            acq_data.append([e.get("filename", ""), e.get("vendor", ""), str(e.get("created_at", "")), e.get("acquisition_method", "Upload"), e.get("status", "Unknown")])
        self._add_table(acq_data)
        
        # 7. EVIDENCE HASHES
        self.story.append(Paragraph("7. Evidence Hashes", self.styles['SectionHeader']))
        hash_data = [["Filename", "SHA-256", "Status"]]
        for e in evidence:
            h = e.get("hash_sha256", "")
            hash_para = Paragraph(h, self.styles['Mono'])
            hash_data.append([e.get("filename", ""), hash_para, e.get("status", "")])
        self._add_table(hash_data, col_widths=[2*inch, 3*inch, 1.5*inch])

        # 8. METADATA
        self.story.append(Paragraph("8. Metadata", self.styles['SectionHeader']))
        meta_data = [["Filename", "Codec", "Resolution", "Duration", "FPS", "Frames"]]
        for e in evidence:
            meta = e.get("metadata", {})
            meta_data.append([
                e.get("filename", ""), 
                meta.get("codec", "N/A"), 
                f"{meta.get('width', 0)}x{meta.get('height', 0)}",
                str(meta.get("duration", "N/A")),
                str(meta.get("fps", "N/A")),
                str(meta.get("frame_count", "N/A"))
            ])
        self._add_table(meta_data)

        # 9. RECOVERY RESULTS
        self.story.append(Paragraph("9. Recovery Results", self.styles['SectionHeader']))
        rec_data = [["Method", "Success", "Items Found", "Demo"]]
        for r in recovery_results:
            rec_data.append([
                r.get("method", ""),
                str(r.get("success", False)),
                str(r.get("items_found", 0)),
                "YES" if r.get("is_demo") else "NO"
            ])
        if len(rec_data) > 1:
            self._add_table(rec_data)
        else:
            self.story.append(Paragraph("No recovery operations performed.", self.styles['Normal']))

        # 10. ANALYSIS FINDINGS
        self.story.append(Paragraph("10. Analysis Findings", self.styles['SectionHeader']))
        finding_data = [["Event Type", "Count", "Demo"]]
        counts = {}
        demo_counts = {}
        for a in analysis_events:
            etype = a.get("event_type", "Unknown")
            is_demo = a.get("is_demo", False)
            counts[etype] = counts.get(etype, 0) + 1
            if is_demo:
                demo_counts[etype] = demo_counts.get(etype, 0) + 1
                
        for etype, count in counts.items():
            demo_count = demo_counts.get(etype, 0)
            finding_data.append([etype, str(count), "YES" if demo_count > 0 else "NO"])
        
        if len(finding_data) > 1:
            self._add_table(finding_data)
        else:
            self.story.append(Paragraph("No analysis events found.", self.styles['Normal']))

        # 11. TIMELINE
        self.story.append(Paragraph("11. Timeline", self.styles['SectionHeader']))
        time_data = [["Timestamp", "Event Type", "Confidence"]]
        sorted_events = sorted(analysis_events, key=lambda x: x.get("timestamp", ""))
        for e in sorted_events[:50]: # Limit to 50 for report
            time_data.append([str(e.get("timestamp", "")), e.get("event_type", ""), str(e.get("confidence", ""))])
        if len(time_data) > 1:
            self._add_table(time_data)
            if len(analysis_events) > 50:
                self.story.append(Paragraph(f"(Showing first 50 of {len(analysis_events)} events)", self.styles['Normal']))
        else:
            self.story.append(Paragraph("No events in timeline.", self.styles['Normal']))

        # 12. CROSS-CAMERA CORRELATION
        self.story.append(Paragraph("12. Cross-Camera Correlation", self.styles['SectionHeader']))
        self.story.append(Paragraph("No cross-camera correlations defined in this case.", self.styles['Normal']))

        # 13. INVESTIGATOR ANNOTATIONS
        self.story.append(Paragraph("13. Investigator Annotations", self.styles['SectionHeader']))
        ann_data = [["Type", "Text", "Evidence ID"]]
        for a in annotations:
            ann_data.append(["Annotation", a.get("text", ""), a.get("evidence_id", "")])
        for b in bookmarks:
            ann_data.append(["Bookmark", b.get("title", ""), b.get("evidence_id", "")])
        if len(ann_data) > 1:
            self._add_table(ann_data)
        else:
            self.story.append(Paragraph("No annotations or bookmarks found.", self.styles['Normal']))

        # 14. CHAIN OF CUSTODY
        self.story.append(Paragraph("14. Chain of Custody", self.styles['SectionHeader']))
        log_data = [["Timestamp", "Actor", "Action", "Evidence ID"]]
        for l in audit_logs:
            log_data.append([str(l.get("timestamp", "")), l.get("actor", ""), l.get("action", ""), str(l.get("evidence_id", ""))])
        if len(log_data) > 1:
            self._add_table(log_data)
        else:
            self.story.append(Paragraph("No audit logs found.", self.styles['Normal']))

        # 15. LEDGER VERIFICATION
        self.story.append(Paragraph("15. Ledger Verification", self.styles['SectionHeader']))
        self.story.append(Paragraph(f"<b>Blocks:</b> {len(ledger_blocks)}", self.styles['Normal']))
        if ledger_blocks:
            self.story.append(Paragraph(f"<b>Genesis Hash:</b>", self.styles['Normal']))
            self.story.append(Paragraph(ledger_blocks[0].get("hash", ""), self.styles['Mono']))
            self.story.append(Paragraph(f"<b>Latest Hash:</b>", self.styles['Normal']))
            self.story.append(Paragraph(ledger_blocks[-1].get("hash", ""), self.styles['Mono']))
        
        # 16. DISCLAIMER
        self.story.append(Paragraph("16. Disclaimer", self.styles['SectionHeader']))
        disclaimer_text = "PramaanSync is a forensic analysis prototype. Recovery capabilities depend on source format and storage condition. Demo/AI-generated findings are investigative aids and require human validation."
        self.story.append(Paragraph(disclaimer_text, self.styles['Normal']))

        doc.build(self.story, onFirstPage=self._header_footer, onLaterPages=self._header_footer)
        return filepath
