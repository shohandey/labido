"""
PramaanSync Development Runner
Launches FastAPI backend and Vite frontend together.
"""
import subprocess
import sys
import os
import signal
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BACKEND_DIR = ROOT / "backend"
FRONTEND_DIR = ROOT / "frontend"


def check_prerequisites():
    """Check that required tools are available."""
    import shutil
    
    checks = {
        "python": shutil.which("python") or shutil.which("python3"),
        "node": shutil.which("node"),
        "npm": shutil.which("npm"),
        "ffmpeg": shutil.which("ffmpeg"),
        "ffprobe": shutil.which("ffprobe"),
    }
    
    missing = [k for k, v in checks.items() if not v]
    if missing:
        print(f"⚠ Missing prerequisites: {', '.join(missing)}")
        print("See README.md for installation instructions.")
        if "python" in missing or "node" in missing or "npm" in missing:
            sys.exit(1)
    
    # Check MongoDB
    try:
        import pymongo
        client = pymongo.MongoClient("mongodb://localhost:27017", serverSelectionTimeoutMS=2000)
        client.server_info()
        print("✓ MongoDB connected")
        client.close()
    except Exception:
        try:
            result = subprocess.run(
                ["mongosh", "--eval", "db.runCommand({ping:1})", "--quiet"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                print("✓ MongoDB connected")
            else:
                print("⚠ MongoDB may not be running. Start mongod first.")
        except Exception:
            print("⚠ Could not verify MongoDB. Make sure mongod is running on port 27017.")
    
    for name, path in checks.items():
        status = "✓" if path else "✗"
        print(f"  {status} {name}: {path or 'NOT FOUND'}")


def run():
    """Launch backend and frontend processes."""
    check_prerequisites()
    
    processes = []
    
    try:
        # Start FastAPI backend
        print("\n▶ Starting FastAPI backend on http://localhost:8000 ...")
        backend_proc = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "main:app", "--reload", "--host", "0.0.0.0", "--port", "8000"],
            cwd=str(BACKEND_DIR),
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )
        processes.append(("Backend", backend_proc))
        time.sleep(2)
        
        # Start Vite frontend
        print("▶ Starting Vite frontend on http://localhost:5173 ...")
        frontend_proc = subprocess.Popen(
            ["npm", "run", "dev"],
            cwd=str(FRONTEND_DIR),
            shell=True,
        )
        processes.append(("Frontend", frontend_proc))
        
        print("\n" + "=" * 60)
        print("  PramaanSync Development Server")
        print("=" * 60)
        print(f"  Backend:  http://localhost:8000")
        print(f"  Frontend: http://localhost:5173")
        print(f"  API Docs: http://localhost:8000/docs")
        print("=" * 60)
        print("  Press Ctrl+C to stop all servers")
        print("=" * 60 + "\n")
        
        # Wait for processes
        while True:
            for name, proc in processes:
                if proc.poll() is not None:
                    print(f"\n⚠ {name} process exited with code {proc.returncode}")
                    raise KeyboardInterrupt
            time.sleep(1)
    
    except KeyboardInterrupt:
        print("\n\n⏹ Shutting down...")
        for name, proc in processes:
            try:
                proc.terminate()
                proc.wait(timeout=5)
                print(f"  ✓ {name} stopped")
            except subprocess.TimeoutExpired:
                proc.kill()
                print(f"  ✓ {name} killed")
            except Exception:
                pass
        print("Done.")


if __name__ == "__main__":
    run()
