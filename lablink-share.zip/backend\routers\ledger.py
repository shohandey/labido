from fastapi import APIRouter, Depends
from dependencies import get_ledger_service

router = APIRouter(prefix="/ledger", tags=["ledger"])

@router.get("")
async def list_ledger(skip: int = 0, limit: int = 100, ledger_service = Depends(get_ledger_service)):
    return await ledger_service.get_blocks(skip, limit)

@router.post("/verify")
async def verify_ledger(ledger_service = Depends(get_ledger_service)):
    return await ledger_service.verify_chain()
