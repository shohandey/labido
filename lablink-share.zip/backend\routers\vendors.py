from fastapi import APIRouter
from backend.adapters.hikvision import HikvisionAdapter
from backend.adapters.dahua import DahuaAdapter
from backend.adapters.cpplus import CPPlusAdapter
from backend.adapters.generic import GenericAdapter

router = APIRouter(prefix="/api/vendors", tags=["vendors"])

@router.get("")
async def get_vendors():
    adapters = [
        HikvisionAdapter(),
        DahuaAdapter(),
        CPPlusAdapter(),
        GenericAdapter()
    ]
    return [
        {
            "name": adapter.vendor_name,
            "display_name": adapter.vendor_name.capitalize(),
            "capabilities": list(adapter.capabilities())
        }
        for adapter in adapters
    ]
