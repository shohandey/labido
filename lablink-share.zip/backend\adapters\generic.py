import subprocess
import json
from .base import VendorAdapter

class GenericAdapter(VendorAdapter):
    vendor_name = 'generic'
    
    async def identify(self, filepath: str) -> bool:
        return True
        
    async def parse_metadata(self, filepath: str) -> dict:
        try:
            cmd = ['ffprobe', '-v', 'quiet', '-print_format', 'json', '-show_format', '-show_streams', filepath]
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            info = json.loads(result.stdout)
            return {"vendor": self.vendor_name, "ffprobe": info}
        except Exception as e:
            return {"vendor": self.vendor_name, "error": str(e)}
            
    def capabilities(self) -> set:
        return {'import'}
