import asyncio
import hashlib
from datetime import datetime
from bson import ObjectId

class LedgerService:
    def __init__(self, db):
        self.db = db
        self._lock = asyncio.Lock()

    async def append_block(self, action: str, evidence_id: str, data_hash: str):
        async with self._lock:
            last_block = await self.db.ledger_blocks.find_one(sort=[("block_no", -1)])
            block_no = last_block["block_no"] + 1 if last_block else 1
            previous_hash = last_block["current_hash"] if last_block else '0' * 64
            timestamp_iso = datetime.utcnow().isoformat()
            
            raw_data = str(block_no) + timestamp_iso + action + evidence_id + data_hash + previous_hash
            current_hash = hashlib.sha256(raw_data.encode('utf-8')).hexdigest()
            
            block = {
                "block_no": block_no,
                "timestamp": timestamp_iso,
                "action": action,
                "evidence_id": evidence_id,
                "data_hash": data_hash,
                "previous_hash": previous_hash,
                "current_hash": current_hash
            }
            res = await self.db.ledger_blocks.insert_one(block)
            block["_id"] = str(res.inserted_id)
            return block

    async def verify_chain(self) -> dict:
        cursor = self.db.ledger_blocks.find().sort("block_no", 1)
        blocks = await cursor.to_list(length=None)
        
        if not blocks:
            return {"valid": True, "first_bad_block": None}
            
        previous_hash = '0' * 64
        for i, block in enumerate(blocks):
            if block["block_no"] != i + 1:
                return {"valid": False, "first_bad_block": block["block_no"], "reason": "Non-sequential block number"}
            
            if block["previous_hash"] != previous_hash:
                return {"valid": False, "first_bad_block": block["block_no"], "reason": "Previous hash mismatch"}
                
            raw_data = str(block["block_no"]) + block["timestamp"] + block["action"] + block["evidence_id"] + block["data_hash"] + block["previous_hash"]
            computed_hash = hashlib.sha256(raw_data.encode('utf-8')).hexdigest()
            
            if block["current_hash"] != computed_hash:
                return {"valid": False, "first_bad_block": block["block_no"], "reason": "Current hash mismatch"}
                
            previous_hash = block["current_hash"]
            
        return {"valid": True, "first_bad_block": None}

    async def get_blocks(self, skip: int = 0, limit: int = 100):
        cursor = self.db.ledger_blocks.find().sort("block_no", 1).skip(skip).limit(limit)
        blocks = await cursor.to_list(length=limit)
        for b in blocks:
            b["_id"] = str(b["_id"])
        return blocks

    async def get_block_count(self):
        return await self.db.ledger_blocks.count_documents({})
