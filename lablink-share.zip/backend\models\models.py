from typing import Optional, Literal
from datetime import datetime
from pydantic import BaseModel, Field

class CaseCreate(BaseModel):
    name: str
    description: str
    investigator_name: str

class Case(CaseCreate):
    id: str = Field(alias="_id")
    created_at: datetime
    updated_at: datetime

class DeviceCreate(BaseModel):
    case_id: str
    name: str
    vendor: str
    model: Optional[str] = None
    serial: Optional[str] = None
    location: Optional[str] = None

class Device(DeviceCreate):
    id: str = Field(alias="_id")

class EvidenceMetadata(BaseModel):
    codec: Optional[str] = None
    resolution: Optional[str] = None
    duration: Optional[float] = None
    fps: Optional[float] = None
    bitrate: Optional[int] = None
    frame_count: Optional[int] = None

class EvidenceCreate(BaseModel):
    case_id: str
    device_id: str
    filename: str
    original_path: str
    working_path: str
    sha256: str
    status: Literal['original', 'repaired', 'carved', 'fragmented']
    vendor: str
    is_demo: bool = False
    metadata: EvidenceMetadata = EvidenceMetadata()
    file_size: Optional[int] = None

class Evidence(EvidenceCreate):
    id: str = Field(alias="_id")
    created_at: datetime

class RecoveryResultCreate(BaseModel):
    evidence_id: str
    method: Literal['stream_repair', 'file_carve', 'vendor_index']
    success: bool
    items_found: int
    details: dict
    thumbnail_path: Optional[str] = None

class RecoveryResult(RecoveryResultCreate):
    id: str = Field(alias="_id")
    created_at: datetime

class AnalysisEventCreate(BaseModel):
    evidence_id: str
    case_id: str
    event_type: str
    timestamp_sec: float
    duration_sec: float
    confidence: float
    details: dict
    is_demo: bool = False

class AnalysisEvent(AnalysisEventCreate):
    id: str = Field(alias="_id")
    created_at: datetime

class AuditLogCreate(BaseModel):
    case_id: str
    evidence_id: Optional[str] = None
    action: str
    actor: str
    details: dict
    result: str

class AuditLog(AuditLogCreate):
    id: str = Field(alias="_id")
    created_at: datetime

class LedgerBlock(BaseModel):
    id: str = Field(alias="_id")
    block_no: int
    timestamp: str
    action: str
    evidence_id: str
    data_hash: str
    previous_hash: str
    current_hash: str

class ProcessingJobCreate(BaseModel):
    case_id: Optional[str] = None
    evidence_id: Optional[str] = None
    type: str
    status: Literal['QUEUED', 'RUNNING', 'COMPLETED', 'FAILED', 'CANCELLED'] = 'QUEUED'
    progress: int = 0
    message: str = ''
    result: Optional[dict] = None

class ProcessingJob(ProcessingJobCreate):
    id: str = Field(alias="_id")
    created_at: datetime
    updated_at: datetime

class BookmarkCreate(BaseModel):
    evidence_id: str
    timestamp_sec: float
    label: str

class Bookmark(BookmarkCreate):
    id: str = Field(alias="_id")
    created_at: datetime

class AnnotationCreate(BaseModel):
    evidence_id: str
    content: str
    timestamp_sec: Optional[float] = None

class Annotation(AnnotationCreate):
    id: str = Field(alias="_id")
    created_at: datetime
