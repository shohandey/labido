from fastapi import APIRouter, Depends
from database import get_database

router = APIRouter(prefix="/search", tags=["search"])

@router.get("")
async def search_all(q: str, db = Depends(get_database)):
    regex = {"$regex": q, "$options": "i"}
    
    cases_cur = db.cases.find({"$or": [{"name": regex}, {"description": regex}]})
    cases = await cases_cur.to_list(20)
    for c in cases: c["_id"] = str(c["_id"])
    
    ev_cur = db.evidence.find({"$or": [{"filename": regex}, {"sha256": regex}]})
    evidence = await ev_cur.to_list(20)
    for e in evidence: e["_id"] = str(e["_id"])
    
    dev_cur = db.devices.find({"$or": [{"name": regex}, {"serial": regex}]})
    devices = await dev_cur.to_list(20)
    for d in devices: d["_id"] = str(d["_id"])
    
    events_cur = db.analysis_events.find({"event_type": regex})
    events = await events_cur.to_list(20)
    for ev in events: ev["_id"] = str(ev["_id"])
    
    return {
        "cases": cases,
        "evidence": evidence,
        "devices": devices,
        "events": events
    }
