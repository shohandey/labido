"""
PramaanSync Database Seeder

Seeds the MongoDB database with realistic demo data:
- 2 demo cases
- 3 devices
- Normal, corrupted, and fragmented MP4 files (generated via FFmpeg lavfi)
- Audit history (via audit_service)
- Valid ledger chain (via ledger_service)
- Analysis events with cross-camera incident clusters
- Bookmarks and annotations

Usage:
    python scripts/seed.py
"""
import asyncio
import hashlib
import os
import shutil
import subprocess
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

# Add backend to path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

from motor.motor_asyncio import AsyncIOMotorClient
from config import get_settings
from services.ledger_service import LedgerService
from services.audit_service import AuditService


def generate_test_video(output_path: str, duration: float = 10.0, label: str = "CAM-01",
                         resolution: str = "640x480", corrupt: bool = False):
    """Generate a synthetic test video using FFmpeg lavfi filters."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # Build filter with camera label, timestamp, and moving pattern
    filter_str = (
        f"color=c=black:s={resolution}:d={duration}:r=25,"
        f"drawtext=text='{label}':fontcolor=white:fontsize=24:x=10:y=10,"
        f"drawtext=text='%{{pts\\:hms}}':fontcolor=cyan:fontsize=20:x=10:y=40,"
        f"drawtext=text='PramaanSync Demo':fontcolor=gray:fontsize=16:x=10:y=(h-30),"
        f"drawgrid=width=64:height=64:thickness=1:color=gray@0.3"
    )

    cmd = [
        "ffmpeg", "-y",
        "-f", "lavfi", "-i", f"nullsrc=s={resolution}:d={duration}:r=25",
        "-vf", filter_str,
        "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
        "-t", str(duration),
        output_path
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            # Fallback: simpler filter
            cmd_simple = [
                "ffmpeg", "-y",
                "-f", "lavfi", "-i", f"testsrc=size={resolution}:duration={duration}:rate=25",
                "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
                output_path
            ]
            subprocess.run(cmd_simple, capture_output=True, text=True, timeout=30, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"  ⚠ FFmpeg error: {e}")
        # Create a minimal valid MP4 as absolute fallback
        _create_minimal_mp4(output_path)

    if corrupt and os.path.exists(output_path):
        _corrupt_file(output_path)

    return output_path


def _create_minimal_mp4(path: str):
    """Create a minimal MP4 file as fallback when FFmpeg is unavailable."""
    # Minimal MP4 with ftyp and mdat boxes
    ftyp = b'\x00\x00\x00\x1c' + b'ftyp' + b'isom' + b'\x00\x00\x02\x00' + b'isomiso2mp41'
    mdat = b'\x00\x00\x00\x08' + b'mdat'
    with open(path, 'wb') as f:
        f.write(ftyp + mdat + os.urandom(4096))


def _corrupt_file(path: str):
    """Corrupt an MP4 by truncating and inserting bad bytes."""
    with open(path, 'rb') as f:
        data = f.read()
    # Truncate to 70% and corrupt middle section
    truncated = data[:int(len(data) * 0.7)]
    mid = len(truncated) // 2
    corrupted = truncated[:mid] + os.urandom(256) + truncated[mid + 256:]
    with open(path, 'wb') as f:
        f.write(corrupted)


def create_fragmented_file(output_path: str):
    """Create a fake unallocated-space image with embedded MP4 fragments."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    fragments = []
    # Fragment 1: ftyp box
    ftyp = b'\x00\x00\x00\x1c' + b'ftyp' + b'isom' + b'\x00\x00\x02\x00' + b'isomiso2mp41'
    fragments.append(ftyp)

    # Fragment 2: H.264 NAL units
    nal_start = b'\x00\x00\x00\x01'
    sps = nal_start + b'\x67' + os.urandom(32)  # SPS NAL
    pps = nal_start + b'\x68' + os.urandom(8)   # PPS NAL
    idr = nal_start + b'\x65' + os.urandom(512)  # IDR frame
    fragments.append(sps + pps + idr)

    # Build unallocated space image with fragments embedded
    data = bytearray()
    data.extend(os.urandom(2048))  # garbage before
    data.extend(fragments[0])       # ftyp fragment
    data.extend(os.urandom(4096))  # garbage between
    data.extend(fragments[1])       # H.264 fragments
    data.extend(os.urandom(2048))  # garbage after

    with open(output_path, 'wb') as f:
        f.write(bytes(data))

    return output_path


def calculate_sha256(filepath: str) -> str:
    """Calculate SHA-256 hash of file."""
    h = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


async def seed():
    """Main seeder function."""
    settings = get_settings()
    client = AsyncIOMotorClient(settings.MONGO_URI)
    db = client[settings.DATABASE_NAME]

    print("=" * 60)
    print("  PramaanSync Database Seeder")
    print("=" * 60)

    # ── Drop existing data ──
    print("\n▶ Cleaning existing data...")
    for col in ['cases', 'devices', 'evidence', 'recovery_results',
                'analysis_events', 'audit_logs', 'ledger_blocks',
                'processing_jobs', 'bookmarks', 'annotations']:
        await db[col].drop()
    print("  ✓ Collections dropped")

    # ── Create indexes ──
    print("\n▶ Creating indexes...")
    await db.ledger_blocks.create_index("block_no", unique=True)
    await db.analysis_events.create_index([("case_id", 1), ("timestamp_sec", 1)])
    await db.evidence.create_index("case_id")
    await db.audit_logs.create_index([("case_id", 1), ("created_at", 1)])
    await db.recovery_results.create_index("evidence_id")
    await db.cases.create_index("created_at")
    await db.evidence.create_index("sha256")
    await db.analysis_events.create_index("evidence_id")
    await db.processing_jobs.create_index("status")
    print("  ✓ Indexes created")

    # ── Initialize services ──
    ledger_service = LedgerService(db)
    audit_service = AuditService(db, ledger_service)

    # ── Create evidence directories ──
    evidence_root = Path(settings.EVIDENCE_ROOT)
    for subdir in ['originals', 'working', 'thumbnails', 'carved']:
        (evidence_root / subdir).mkdir(parents=True, exist_ok=True)
    Path(settings.REPORT_ROOT).mkdir(parents=True, exist_ok=True)

    # ══════════════════════════════════════════════
    # CASE 1: Shopping Mall CCTV Investigation
    # ══════════════════════════════════════════════
    print("\n▶ Creating Case 1: Shopping Mall CCTV Investigation...")
    now = datetime.now(timezone.utc)
    case1_id = str(uuid.uuid4())
    await db.cases.insert_one({
        "_id": case1_id,
        "name": "CASE-2026-001",
        "description": "Surveillance footage analysis from GreenPark Mall incident on 2026-09-05. Multiple cameras covering main entrance, parking lot, and food court.",
        "investigator_name": "Inspector Rajesh Kumar",
        "created_at": (now - timedelta(days=5)).isoformat(),
        "updated_at": now.isoformat(),
    })
    print(f"  ✓ Case: CASE-2026-001 ({case1_id})")

    # ── Case 1 Devices ──
    devices_case1 = []
    device_specs = [
        ("CAM-01-ENTRANCE", "hikvision", "DS-2CD2143G2-I", "HK20260101", "Main Entrance Gate"),
        ("CAM-02-PARKING", "dahua", "IPC-HFW2831E-S", "DH20260042", "Parking Lot B2"),
        ("CAM-03-FOODCOURT", "cpplus", "CP-UNC-TA21PL3-V3", "CP20260103", "Food Court East Wing"),
    ]
    for name, vendor, model, serial, location in device_specs:
        dev_id = str(uuid.uuid4())
        await db.devices.insert_one({
            "_id": dev_id,
            "case_id": case1_id,
            "name": name,
            "vendor": vendor,
            "model": model,
            "serial": serial,
            "location": location,
        })
        devices_case1.append((dev_id, name, vendor))
        print(f"  ✓ Device: {name} ({vendor})")

    # ── Generate test videos ──
    print("\n▶ Generating test video files...")
    
    # Video 1: Normal (CAM-01)
    orig_dir_c1 = evidence_root / "originals" / case1_id
    work_dir_c1 = evidence_root / "working" / case1_id
    thumb_dir = evidence_root / "thumbnails"
    orig_dir_c1.mkdir(parents=True, exist_ok=True)
    work_dir_c1.mkdir(parents=True, exist_ok=True)
    thumb_dir.mkdir(parents=True, exist_ok=True)

    vid1_name = "cam01_entrance_20260905_103500.mp4"
    vid1_orig = str(orig_dir_c1 / vid1_name)
    generate_test_video(vid1_orig, duration=15.0, label="CAM-01 ENTRANCE", resolution="1280x720")
    vid1_hash = calculate_sha256(vid1_orig)
    vid1_work = str(work_dir_c1 / vid1_name)
    shutil.copy2(vid1_orig, vid1_work)
    print(f"  ✓ {vid1_name} (normal)")

    # Video 2: Corrupted (CAM-02)
    vid2_name = "cam02_parking_20260905_103520.mp4"
    vid2_orig = str(orig_dir_c1 / vid2_name)
    generate_test_video(vid2_orig, duration=12.0, label="CAM-02 PARKING", resolution="1280x720", corrupt=True)
    vid2_hash = calculate_sha256(vid2_orig)
    vid2_work = str(work_dir_c1 / vid2_name)
    shutil.copy2(vid2_orig, vid2_work)
    print(f"  ✓ {vid2_name} (corrupted)")

    # Video 3: Normal (CAM-03)
    vid3_name = "cam03_foodcourt_20260905_103540.mp4"
    vid3_orig = str(orig_dir_c1 / vid3_name)
    generate_test_video(vid3_orig, duration=10.0, label="CAM-03 FOODCOURT", resolution="1280x720")
    vid3_hash = calculate_sha256(vid3_orig)
    vid3_work = str(work_dir_c1 / vid3_name)
    shutil.copy2(vid3_orig, vid3_work)
    print(f"  ✓ {vid3_name} (normal)")

    # ── Generate thumbnails ──
    for vid_name in [vid1_name, vid2_name, vid3_name]:
        vid_path = str(work_dir_c1 / vid_name)
        thumb_path = str(thumb_dir / f"{Path(vid_name).stem}_thumb.jpg")
        try:
            subprocess.run([
                "ffmpeg", "-y", "-i", vid_path,
                "-vframes", "1", "-ss", "1",
                "-vf", "scale=320:-1",
                thumb_path
            ], capture_output=True, timeout=10)
        except Exception:
            pass  # Thumbnail generation is best-effort

    # ── Create evidence records & audit trail ──
    print("\n▶ Creating evidence records...")
    evidence_ids = []
    evidence_data = [
        (vid1_name, vid1_orig, vid1_work, vid1_hash, "original", devices_case1[0], False),
        (vid2_name, vid2_orig, vid2_work, vid2_hash, "fragmented", devices_case1[1], False),
        (vid3_name, vid3_orig, vid3_work, vid3_hash, "original", devices_case1[2], False),
    ]

    for filename, orig_path, work_path, sha256, status, (dev_id, dev_name, vendor), is_demo in evidence_data:
        ev_id = str(uuid.uuid4())
        evidence_ids.append(ev_id)

        # Extract metadata via ffprobe if available
        metadata = {
            "codec": "h264",
            "resolution": "1280x720",
            "duration": 15.0 if "cam01" in filename else 12.0 if "cam02" in filename else 10.0,
            "fps": 25.0,
            "bitrate": 500000,
            "frame_count": int((15.0 if "cam01" in filename else 12.0 if "cam02" in filename else 10.0) * 25),
        }

        try:
            probe_cmd = [
                "ffprobe", "-v", "quiet", "-print_format", "json",
                "-show_format", "-show_streams", work_path
            ]
            probe_result = subprocess.run(probe_cmd, capture_output=True, text=True, timeout=10)
            if probe_result.returncode == 0:
                import json
                probe_data = json.loads(probe_result.stdout)
                if probe_data.get("streams"):
                    stream = probe_data["streams"][0]
                    metadata["codec"] = stream.get("codec_name", "h264")
                    metadata["resolution"] = f"{stream.get('width', 1280)}x{stream.get('height', 720)}"
                    if "r_frame_rate" in stream:
                        parts = stream["r_frame_rate"].split("/")
                        if len(parts) == 2 and int(parts[1]) > 0:
                            metadata["fps"] = round(int(parts[0]) / int(parts[1]), 2)
                if probe_data.get("format"):
                    fmt = probe_data["format"]
                    metadata["duration"] = float(fmt.get("duration", metadata["duration"]))
                    metadata["bitrate"] = int(fmt.get("bit_rate", metadata["bitrate"]))
                    metadata["frame_count"] = int(metadata["duration"] * metadata["fps"])
        except Exception:
            pass

        file_size = os.path.getsize(orig_path) if os.path.exists(orig_path) else 0
        thumb_name = f"{Path(filename).stem}_thumb.jpg"
        thumb_path_val = str(thumb_dir / thumb_name) if (thumb_dir / thumb_name).exists() else None

        await db.evidence.insert_one({
            "_id": ev_id,
            "case_id": case1_id,
            "device_id": dev_id,
            "filename": filename,
            "original_path": orig_path,
            "working_path": work_path,
            "sha256": sha256,
            "status": status,
            "vendor": vendor,
            "is_demo": True,
            "created_at": (now - timedelta(days=5, hours=-(evidence_data.index((filename, orig_path, work_path, sha256, status, (dev_id, dev_name, vendor), is_demo))))).isoformat(),
            "metadata": metadata,
            "file_size": file_size,
            "thumbnail_path": thumb_path_val,
        })

        # Audit: evidence acquired
        await audit_service.log_action(
            case_id=case1_id,
            evidence_id=ev_id,
            action="EVIDENCE_ACQUIRED",
            actor="Inspector Rajesh Kumar",
            details={"filename": filename, "vendor": vendor, "sha256": sha256},
            result="SUCCESS",
        )
        print(f"  ✓ Evidence: {filename} ({ev_id[:8]}...)")

    # ── Verify hashes (creates audit + ledger entries) ──
    print("\n▶ Recording hash verifications...")
    for i, ev_id in enumerate(evidence_ids):
        await audit_service.log_action(
            case_id=case1_id,
            evidence_id=ev_id,
            action="HASH_VERIFIED",
            actor="Inspector Rajesh Kumar",
            details={"result": "match", "algorithm": "SHA-256"},
            result="SUCCESS",
        )
    print("  ✓ Hash verifications recorded")

    # ── Recovery results for corrupted video ──
    print("\n▶ Creating recovery results...")
    recovery_id = str(uuid.uuid4())
    await db.recovery_results.insert_one({
        "_id": recovery_id,
        "evidence_id": evidence_ids[1],  # corrupted video
        "method": "stream_repair",
        "success": True,
        "items_found": 1,
        "details": {
            "method": "ffmpeg_remux",
            "error_handling": "ignore_err+genpts+igndts",
            "recovered_fraction": 0.72,
            "input_duration": 12.0,
            "output_duration": 8.64,
            "is_demo": True,
        },
        "thumbnail_path": None,
        "created_at": (now - timedelta(days=4)).isoformat(),
    })

    recovery_id2 = str(uuid.uuid4())
    await db.recovery_results.insert_one({
        "_id": recovery_id2,
        "evidence_id": evidence_ids[1],
        "method": "file_carve",
        "success": True,
        "items_found": 3,
        "details": {
            "scan_method": "signature_scan",
            "signatures_searched": ["ftyp", "h264_nalu", "h264_short_nalu"],
            "fragments": [
                {"type": "mp4_ftyp", "size": 24576, "repaired": True},
                {"type": "h264_nalu", "size": 8192, "repaired": False},
                {"type": "h264_nalu", "size": 16384, "repaired": True},
            ],
            "is_demo": True,
        },
        "thumbnail_path": None,
        "created_at": (now - timedelta(days=4)).isoformat(),
    })

    recovery_id3 = str(uuid.uuid4())
    await db.recovery_results.insert_one({
        "_id": recovery_id3,
        "evidence_id": evidence_ids[1],
        "method": "vendor_index",
        "success": False,
        "items_found": 0,
        "details": {
            "reason": "Vendor index parsing not fully supported for dahua format",
            "is_demo": True,
        },
        "thumbnail_path": None,
        "created_at": (now - timedelta(days=4)).isoformat(),
    })

    await audit_service.log_action(
        case_id=case1_id,
        evidence_id=evidence_ids[1],
        action="RECOVERY_COMPLETED",
        actor="System",
        details={"methods": ["stream_repair", "file_carve", "vendor_index"], "is_demo": True},
        result="PARTIAL_SUCCESS",
    )
    print("  ✓ Recovery results created")

    # ══════════════════════════════════════════════
    # ANALYSIS EVENTS — Cross-Camera Incidents
    # ══════════════════════════════════════════════
    print("\n▶ Creating analysis events (cross-camera incidents)...")

    # Incident Cluster 1: ~10:35:41 — Motion across 3 cameras
    events_cluster1 = [
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[0],
            "case_id": case1_id,
            "event_type": "motion",
            "timestamp_sec": 341.0,  # 5:41 into video ≈ 10:35:41
            "duration_sec": 3.5,
            "confidence": 0.87,
            "details": {"area_percent": 12.4, "quadrant": "center-right", "camera": "CAM-01"},
            "is_demo": True,
            "created_at": (now - timedelta(days=4, hours=2)).isoformat(),
        },
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[1],
            "case_id": case1_id,
            "event_type": "person",
            "timestamp_sec": 344.0,  # 10:35:44
            "duration_sec": 5.0,
            "confidence": 0.82,
            "details": {"label": "person", "bbox": [120, 80, 240, 360], "camera": "CAM-02"},
            "is_demo": True,
            "created_at": (now - timedelta(days=4, hours=2)).isoformat(),
        },
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[2],
            "case_id": case1_id,
            "event_type": "motion",
            "timestamp_sec": 348.0,  # 10:35:48
            "duration_sec": 2.8,
            "confidence": 0.79,
            "details": {"area_percent": 8.7, "quadrant": "left", "camera": "CAM-03"},
            "is_demo": True,
            "created_at": (now - timedelta(days=4, hours=2)).isoformat(),
        },
    ]

    # Incident Cluster 2: ~10:42:15 — Vehicle + Motion
    events_cluster2 = [
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[0],
            "case_id": case1_id,
            "event_type": "vehicle",
            "timestamp_sec": 735.0,
            "duration_sec": 8.0,
            "confidence": 0.91,
            "details": {"label": "vehicle", "bbox": [300, 200, 520, 380], "camera": "CAM-01"},
            "is_demo": True,
            "created_at": (now - timedelta(days=4, hours=1)).isoformat(),
        },
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[1],
            "case_id": case1_id,
            "event_type": "motion",
            "timestamp_sec": 738.0,
            "duration_sec": 6.0,
            "confidence": 0.85,
            "details": {"area_percent": 22.1, "quadrant": "full", "camera": "CAM-02"},
            "is_demo": True,
            "created_at": (now - timedelta(days=4, hours=1)).isoformat(),
        },
    ]

    # Incident Cluster 3: ~10:50:30 — Person across 2 cameras
    events_cluster3 = [
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[0],
            "case_id": case1_id,
            "event_type": "person",
            "timestamp_sec": 1230.0,
            "duration_sec": 4.0,
            "confidence": 0.88,
            "details": {"label": "person", "bbox": [100, 50, 200, 350], "camera": "CAM-01"},
            "is_demo": True,
            "created_at": (now - timedelta(days=4, hours=0, minutes=30)).isoformat(),
        },
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[2],
            "case_id": case1_id,
            "event_type": "person",
            "timestamp_sec": 1233.0,
            "duration_sec": 6.0,
            "confidence": 0.76,
            "details": {"label": "person", "bbox": [400, 100, 560, 400], "camera": "CAM-03"},
            "is_demo": True,
            "created_at": (now - timedelta(days=4, hours=0, minutes=30)).isoformat(),
        },
    ]

    # Additional standalone events (not clustered)
    standalone_events = [
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[0],
            "case_id": case1_id,
            "event_type": "motion",
            "timestamp_sec": 120.0,
            "duration_sec": 2.0,
            "confidence": 0.65,
            "details": {"area_percent": 5.2, "quadrant": "top-left", "camera": "CAM-01"},
            "is_demo": True,
            "created_at": (now - timedelta(days=4, hours=3)).isoformat(),
        },
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[2],
            "case_id": case1_id,
            "event_type": "face",
            "timestamp_sec": 500.0,
            "duration_sec": 1.5,
            "confidence": 0.72,
            "details": {"label": "face", "bbox": [200, 80, 260, 160], "camera": "CAM-03"},
            "is_demo": True,
            "created_at": (now - timedelta(days=4, hours=2, minutes=30)).isoformat(),
        },
    ]

    all_events = events_cluster1 + events_cluster2 + events_cluster3 + standalone_events
    if all_events:
        await db.analysis_events.insert_many(all_events)
    print(f"  ✓ {len(all_events)} analysis events created (3 incident clusters)")

    await audit_service.log_action(
        case_id=case1_id,
        evidence_id=evidence_ids[0],
        action="ANALYSIS_COMPLETED",
        actor="System",
        details={"events_found": len(all_events), "is_demo": True},
        result="SUCCESS",
    )

    # ══════════════════════════════════════════════
    # CASE 2: Highway Toll Camera Investigation
    # ══════════════════════════════════════════════
    print("\n▶ Creating Case 2: Highway Toll Camera Investigation...")
    case2_id = str(uuid.uuid4())
    await db.cases.insert_one({
        "_id": case2_id,
        "name": "CASE-2026-002",
        "description": "Toll plaza surveillance analysis for hit-and-run incident on NH-48. Single Hikvision camera covering the toll booth lane.",
        "investigator_name": "SI Priya Sharma",
        "created_at": (now - timedelta(days=2)).isoformat(),
        "updated_at": now.isoformat(),
    })

    # Device for case 2
    dev_c2_id = str(uuid.uuid4())
    await db.devices.insert_one({
        "_id": dev_c2_id,
        "case_id": case2_id,
        "name": "CAM-TOLL-01",
        "vendor": "hikvision",
        "model": "DS-2CD2T47G2-L",
        "serial": "HK20260205",
        "location": "Toll Plaza Lane 3",
    })

    # Generate video for case 2
    orig_dir_c2 = evidence_root / "originals" / case2_id
    work_dir_c2 = evidence_root / "working" / case2_id
    orig_dir_c2.mkdir(parents=True, exist_ok=True)
    work_dir_c2.mkdir(parents=True, exist_ok=True)

    vid4_name = "toll_cam01_20260908_141200.mp4"
    vid4_orig = str(orig_dir_c2 / vid4_name)
    generate_test_video(vid4_orig, duration=8.0, label="TOLL-CAM-01", resolution="1920x1080")
    vid4_hash = calculate_sha256(vid4_orig)
    vid4_work = str(work_dir_c2 / vid4_name)
    shutil.copy2(vid4_orig, vid4_work)

    ev4_id = str(uuid.uuid4())
    await db.evidence.insert_one({
        "_id": ev4_id,
        "case_id": case2_id,
        "device_id": dev_c2_id,
        "filename": vid4_name,
        "original_path": vid4_orig,
        "working_path": vid4_work,
        "sha256": vid4_hash,
        "status": "original",
        "vendor": "hikvision",
        "is_demo": True,
        "created_at": (now - timedelta(days=2)).isoformat(),
        "metadata": {
            "codec": "h264", "resolution": "1920x1080", "duration": 8.0,
            "fps": 25.0, "bitrate": 800000, "frame_count": 200,
        },
        "file_size": os.path.getsize(vid4_orig) if os.path.exists(vid4_orig) else 0,
        "thumbnail_path": None,
    })

    await audit_service.log_action(
        case_id=case2_id,
        evidence_id=ev4_id,
        action="EVIDENCE_ACQUIRED",
        actor="SI Priya Sharma",
        details={"filename": vid4_name, "vendor": "hikvision", "sha256": vid4_hash},
        result="SUCCESS",
    )

    await audit_service.log_action(
        case_id=case2_id,
        evidence_id=ev4_id,
        action="HASH_VERIFIED",
        actor="SI Priya Sharma",
        details={"result": "match", "algorithm": "SHA-256"},
        result="SUCCESS",
    )

    # Fragmented file for case 2
    frag_name = "unallocated_sector_dump.bin"
    frag_path = str(orig_dir_c2 / frag_name)
    create_fragmented_file(frag_path)
    frag_hash = calculate_sha256(frag_path)
    frag_work = str(work_dir_c2 / frag_name)
    shutil.copy2(frag_path, frag_work)

    ev5_id = str(uuid.uuid4())
    await db.evidence.insert_one({
        "_id": ev5_id,
        "case_id": case2_id,
        "device_id": dev_c2_id,
        "filename": frag_name,
        "original_path": frag_path,
        "working_path": frag_work,
        "sha256": frag_hash,
        "status": "fragmented",
        "vendor": "generic",
        "is_demo": True,
        "created_at": (now - timedelta(days=2)).isoformat(),
        "metadata": {
            "codec": "unknown", "resolution": "unknown", "duration": 0,
            "fps": 0, "bitrate": 0, "frame_count": 0,
        },
        "file_size": os.path.getsize(frag_path) if os.path.exists(frag_path) else 0,
        "thumbnail_path": None,
    })

    await audit_service.log_action(
        case_id=case2_id,
        evidence_id=ev5_id,
        action="EVIDENCE_ACQUIRED",
        actor="SI Priya Sharma",
        details={"filename": frag_name, "vendor": "generic", "sha256": frag_hash},
        result="SUCCESS",
    )
    print(f"  ✓ Case 2 with 2 evidence items created")

    # ══════════════════════════════════════════════
    # BOOKMARKS & ANNOTATIONS
    # ══════════════════════════════════════════════
    print("\n▶ Creating bookmarks and annotations...")
    bookmarks = [
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[0],
            "timestamp_sec": 341.0,
            "label": "Person enters through main entrance",
            "created_at": (now - timedelta(days=3)).isoformat(),
        },
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[0],
            "timestamp_sec": 735.0,
            "label": "Vehicle approaches entrance",
            "created_at": (now - timedelta(days=3)).isoformat(),
        },
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[2],
            "timestamp_sec": 500.0,
            "label": "Possible subject sighted in food court",
            "created_at": (now - timedelta(days=3)).isoformat(),
        },
    ]
    if bookmarks:
        await db.bookmarks.insert_many(bookmarks)

    annotations = [
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[0],
            "content": "Subject appears to be male, approximately 5'10\", wearing dark jacket and cap. Enters through Gate A at 10:35:41.",
            "timestamp_sec": 341.0,
            "created_at": (now - timedelta(days=3)).isoformat(),
        },
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[1],
            "content": "Parking lot footage shows a silver sedan (partial plate: MH-04-XX-1234) at 10:35:44. Vehicle is in Zone B2.",
            "timestamp_sec": 344.0,
            "created_at": (now - timedelta(days=3)).isoformat(),
        },
        {
            "_id": str(uuid.uuid4()),
            "evidence_id": evidence_ids[0],
            "content": "Note: Footage between 10:42:00 and 10:42:30 shows significant motion in the entrance area. Possible secondary subject.",
            "timestamp_sec": None,
            "created_at": (now - timedelta(days=2, hours=12)).isoformat(),
        },
    ]
    if annotations:
        await db.annotations.insert_many(annotations)
    print(f"  ✓ {len(bookmarks)} bookmarks and {len(annotations)} annotations created")

    # ══════════════════════════════════════════════
    # VERIFY LEDGER
    # ══════════════════════════════════════════════
    print("\n▶ Verifying ledger chain...")
    result = await ledger_service.verify_chain()
    block_count = await db.ledger_blocks.count_documents({})
    print(f"  Blocks: {block_count}")
    if result["valid"]:
        print("  ✓ LEDGER CHAIN VALID")
    else:
        print(f"  ✗ LEDGER CHAIN INVALID at block #{result['first_bad_block']}")
        print(f"    Reason: {result.get('reason', 'unknown')}")

    # ══════════════════════════════════════════════
    # SUMMARY
    # ══════════════════════════════════════════════
    case_count = await db.cases.count_documents({})
    device_count = await db.devices.count_documents({})
    evidence_count = await db.evidence.count_documents({})
    event_count = await db.analysis_events.count_documents({})
    audit_count = await db.audit_logs.count_documents({})
    ledger_count = await db.ledger_blocks.count_documents({})
    recovery_count = await db.recovery_results.count_documents({})
    bookmark_count = await db.bookmarks.count_documents({})
    annotation_count = await db.annotations.count_documents({})

    print("\n" + "=" * 60)
    print("  Seeding Complete!")
    print("=" * 60)
    print(f"  Cases:           {case_count}")
    print(f"  Devices:         {device_count}")
    print(f"  Evidence:        {evidence_count}")
    print(f"  Recovery:        {recovery_count}")
    print(f"  Analysis Events: {event_count}")
    print(f"  Audit Logs:      {audit_count}")
    print(f"  Ledger Blocks:   {ledger_count}")
    print(f"  Bookmarks:       {bookmark_count}")
    print(f"  Annotations:     {annotation_count}")
    print(f"  Ledger Valid:    {result['valid']}")
    print("=" * 60)

    client.close()


if __name__ == "__main__":
    asyncio.run(seed())
