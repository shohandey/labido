/**
 * LabLink — Conflict Detection Utilities
 *
 * All time comparisons use HH:MM strings converted to minutes-since-midnight
 * for straightforward numeric comparison.
 */

/** Convert "HH:MM" to minutes since midnight */
export function timeToMinutes(timeStr) {
  const [h, m] = timeStr.split(':').map(Number);
  return h * 60 + m;
}

/** Convert minutes since midnight back to "HH:MM" */
export function minutesToTime(minutes) {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/**
 * Checks whether a proposed booking overlaps with any existing approved/pending booking
 * for the same equipment on the same date.
 *
 * @param {Array}  bookings     - all bookings in state
 * @param {string} equipmentId  - equipment id being requested
 * @param {string} date         - "YYYY-MM-DD"
 * @param {string} startTime    - "HH:MM"
 * @param {string} endTime      - "HH:MM"
 * @param {string} [excludeId]  - booking id to exclude (for edits)
 * @returns {{ conflict: boolean, conflictingBooking: object|null }}
 */
export function checkConflict(bookings, equipmentId, date, startTime, endTime, excludeId = null) {
  const reqStart = timeToMinutes(startTime);
  const reqEnd = timeToMinutes(endTime);

  const conflicting = bookings.find((bk) => {
    if (bk.id === excludeId) return false;
    if (bk.equipmentId !== equipmentId) return false;
    if (bk.date !== date) return false;
    if (!['approved', 'pending'].includes(bk.status)) return false;

    const bkStart = timeToMinutes(bk.startTime);
    const bkEnd = timeToMinutes(bk.endTime);

    // Overlap: not (reqEnd <= bkStart || reqStart >= bkEnd)
    return !(reqEnd <= bkStart || reqStart >= bkEnd);
  });

  return { conflict: !!conflicting, conflictingBooking: conflicting || null };
}

/**
 * Finds available 2-hour slots on a given date for a piece of equipment.
 * Scans 08:00–20:00 in 30-minute increments, skipping any that would conflict.
 *
 * @param {Array}  bookings
 * @param {string} equipmentId
 * @param {string} date
 * @param {number} [durationMinutes=120]
 * @returns {Array<{ startTime: string, endTime: string }>}
 */
export function findAvailableSlots(bookings, equipmentId, date, durationMinutes = 120) {
  const slots = [];
  const startOfDay = timeToMinutes('08:00');
  const endOfDay = timeToMinutes('20:00');

  for (let start = startOfDay; start + durationMinutes <= endOfDay; start += 30) {
    const end = start + durationMinutes;
    const { conflict } = checkConflict(
      bookings,
      equipmentId,
      date,
      minutesToTime(start),
      minutesToTime(end)
    );
    if (!conflict) {
      slots.push({ startTime: minutesToTime(start), endTime: minutesToTime(end) });
    }
  }

  return slots;
}

/**
 * Returns a human-readable display for a time range, e.g. "9:00 AM – 11:00 AM".
 */
export function formatTimeRange(startTime, endTime) {
  const fmt = (t) => {
    const [h, m] = t.split(':').map(Number);
    const period = h < 12 ? 'AM' : 'PM';
    const hour = h === 0 ? 12 : h > 12 ? h - 12 : h;
    return `${hour}:${String(m).padStart(2, '0')} ${period}`;
  };
  return `${fmt(startTime)} – ${fmt(endTime)}`;
}
